# Task 07 prompt alignment repair

## 입력 계약 수정

전체 영상 좌표를 유지한다. `first_prompt_frame` 원본 ID를 정렬된 JPEG 목록의 runtime index로 변환한 다음 `--prompt-frame`으로 전달한다. Small/Base+ 모두 같은 index에 같은 object binary mask를 주입하고, 그 시점부터 switch까지 전파한다. crop이나 switch 좌표 변경은 하지 않는다.

cache tensor schema와 object/switch 좌표는 바뀌지 않는다. metadata에는 `prompt_runtime_index`, `prompt_mask_file`, `prompt_mask_sha256`, `prompt_object_id`, `prompt_alignment_policy`가 추가된다. 학습 importer 구조 변경은 필요 없지만 이전의 해당 cache를 이미 학습에 사용했다면 그 결과의 영향을 별도로 검토해야 한다.

## 위치

- 로컬 runtime 수정: `v2-task07-collector-ref/src/vos_memory_inspector/roundtrip.py`, `cli.py`
- 로컬 orchestration 수정: `scripts/task07/prepare_paired_state_dataset.py`, reference checkout의 같은 collector
- CPU audit / GPU repair / verify / 원본 보존 교체: `scripts/task07/repair_prompt_alignment.py`
- GPU CUDA kernel 검사: `scripts/task07/repair_gpu_preflight.py`
- L4 3-worker launcher: `scripts/task07/launch_prompt_repair.sh`
- 새 Storage 작업 디렉터리: `/workspace/CMMT-task07-repair-20261003`
- 기존 production cache는 재수집·전수 검증 완료 전까지 변경하지 않는다.
- GitHub main이나 팀원 브랜치는 이 작업에서 수정·push하지 않는다.

## CPU 확인

후보 39개 manifest entries를 기존 cache와 대조해 **38개 unique caches**의 source/target conditioning `[0]`과 실제 prompt index의 불일치를 확인했다. LVOS train 9개, LVOS validation 18개, M³-VOS 11개다. M³-VOS의 duplicate quantile entry 1개가 같은 cache를 가리켰다. 모든 대상의 기존 checksum, object ID, runtime switch, prompt mask 객체 존재와 RGB/mask 크기가 검사됐다.

CPU plan: `reports/task07/2026-10-03_prompt_repair_plan.json` 및 새 Storage `repair_plan.json`.

## 실행

CPU에는 `/workspace/.venvs/task07-audit` (Python 3.11, torch 2.5.1+cpu)를 생성했다.
GPU에는 `/workspace/.venvs/task07-repair-gpu` (Python 3.12, 기존 torch 2.8.0+cu128 재사용)를 생성했다. SAM2 pinned checkout을 repair 디렉터리로 복사하고 L4 architecture 8.9 extension을 다시 빌드했다. 원본 SAM2 extension은 수정하지 않았다. 3개 L4에서 hole-fill kernel 실제 실행이 통과했다. 기존 수집 GPU/PyTorch 환경과 차이는 provenance에 기록하며 bitwise tensor 동일성을 주장하지 않는다.

```bash
export PYTHONPATH=/workspace/CMMT-task07-repair-20261003/source/src
/workspace/.venvs/task07-audit/bin/python /workspace/repair_prompt_alignment.py audit
CUDA_VISIBLE_DEVICES=0 /workspace/.venvs/task07-repair-gpu/bin/python /workspace/repair_prompt_alignment.py collect --max-cases 1
bash /workspace/launch_prompt_repair.sh
# 3 workers가 모두 끝나고 production writer/reader가 없을 때만 실행
/workspace/.venvs/task07-audit/bin/python /workspace/repair_prompt_alignment.py verify
/workspace/.venvs/task07-audit/bin/python /workspace/repair_prompt_alignment.py promote
/workspace/.venvs/task07-audit/bin/python /workspace/repair_prompt_alignment.py verify-production
```

재수집은 각 case의 prefix 길이(`switch - prompt + 1`)로 longest-first greedy 3-way 분배한다. 각 worker는 서로 다른 output만 쓰므로 claim이나 기존 production queue를 변경하지 않는다. 중단 시 checksum 및 prompt provenance가 통과한 새 cache는 재사용하며, 손상 cache는 자동으로 성공 처리하지 않는다.

## 검증

- Prompt/runtime 및 case cache 관련 22개 CPU tests 통과.
- 전체 reference tests: 86 passed / 1 failed. 실패는 수정하지 않은 M³-VOS inventory test의 failure_count 기대값(1)과 실제값(2) 차이다. prompt 정렬 변경의 회귀라고 확인된 것이 아니며 전체 suite 통과로 보고하지 않는다.
- 가장 긴 repair case `lvos_2vt1LoVz_obj2_switch2801` 단일 L4 검증 통과. full-video runtime conditioning 5, switch 560, 양쪽 object 2 확인.
- **최종 완료:** 38개 재수집·CPU 전수 검증·원본 보존 교체·production 재검증을 완료했다. LVOS train 9개, validation 18개, M³-VOS 11개다. 원본은 `/workspace/CMMT-task07-repair-20261003/original`에 보존돼 있다. 수정본은 기존 production 경로에서 사용한다.
- 완료 근거: `reports/task07/2026-10-04_prompt_alignment_repair_result.md`, `2026-10-04_prompt_repair_promoted.json`, `2026-10-04_prompt_repair_production_verified.json`. GPU 3장 모두 idle을 확인했고 Pod 자동 종료는 하지 않았다.
