# Task 07 prompt alignment repair — 최종 결과

2026-10-04 KST. 사용자 승인 CPU audit → L4 3장 재수집 → CPU 전수 검증 → 원본 보존 교체를 완료했다.

## 원인과 대상

이전 수집 경로는 전체 RGB sequence를 사용하면서 객체 첫 prompt mask를 항상 runtime frame 0에 넣었다. 객체가 뒤늦게 등장하는 경우 mask의 원본 frame과 RGB frame이 달랐다. Small/Base+가 같은 잘못된 위치에 prompt를 넣었으며, 파일 checksum만으로는 이 의미적 오류를 찾을 수 없었다.

| 대상 | 재수집·교체·최종 검증 |
|---|---:|
| LVOS v2 train fit/development | 9 |
| LVOS v2 validation | 18 |
| M³-VOS external | 11 |
| 합계 | 38 unique cache |

Manifest 후보는 39 entries였으나 M³-VOS quantile 중복 1개가 동일 cache를 참조했다. MOSEv2 train/validation, VOST, PUMaVOS는 앞선 원본/manifest 대조에서 late-prompt 불일치가 없었다. 이번에 그 데이터셋 cache 전체를 재생성하거나 tensor 전수 검증했다는 뜻은 아니다.

## 수정된 계약

정렬된 전체 JPEG sequence에서 원본 prompt ID의 runtime index를 구한다. Small/Base+ 모두 동일한 frame·객체 binary mask로 시작해 원래 switch까지 전파한다. 영상 crop이나 switch 좌표 변경은 없다. Cache schema는 유지하고 prompt index·mask SHA-256·object·alignment policy metadata를 추가했다.

기존 manifest, Small/Base+ checkpoint/config, seed 7, num_maskmem 7, max_obj_ptrs 16, state-only/active-memory 정책을 유지했다. GPU/PyTorch 환경은 L4 및 torch 2.8.0+cu128로 과거와 다르므로 bitwise 동일성을 주장하지 않는다. SAM2 pinned checkout의 사본에서 CUDA extension을 다시 빌드했고 3개 GPU 모두 실제 hole-fill CUDA 실행을 통과했다. 재수집 로그에 오류·후처리 경고가 없었다.

## 검증 근거

1. 기존 38개 모두 CPU에서 checksum·object·switch와 conditioning `[0]`을 직접 확인하고 prompt mask/RGB 크기 및 객체 존재를 확인했다.
2. 새 38개 모두 CPU에서 checksum, 양쪽 conditioning index, source/target 유효 frame 목록 일치, prompt..switch 범위, prompt mask digest, object 및 실행 계약을 확인했다.
3. 원본 `.pt`, `.pt.sha256`, `.prepare.json`을 백업하고 모든 백업의 파일 digest를 확인한 뒤 production의 대응 3개 파일을 교체했다. 교체 시 수집 프로세스는 종료돼 있었다.
4. 교체된 production tensor 38개를 다시 읽어 동일 검증을 수행했고, 원본 backup 38개 SHA-256도 CPU audit 당시 값과 일치했다. 결과: `production_verified=38; original_backups_verified=38`.

- 실행 계획: `2026-10-03_prompt_repair_plan.json`
- 교체 ledger: `2026-10-04_prompt_repair_promoted.json`
- production 최종 검증: `2026-10-04_prompt_repair_production_verified.json`
- Storage 작업/로그/새 cache: `/workspace/CMMT-task07-repair-20261003`
- 원본 보존: `/workspace/CMMT-task07-repair-20261003/original/{lvos_train,lvos_valid,m3vos}`
- 수정본은 기존 `/workspace/CMMT-task07-artifacts/production/.../cache/...` 경로에 설치됐다. 학습 importer의 구조 변경은 필요 없다. 이전 해당 cache로 이미 학습한 결과가 있으면 영향을 별도 검토해야 한다.

## 코드와 한계

수정: 로컬 Task 07 reference `roundtrip.py`, `cli.py`, reference collector 및 workspace collector. 추가: CPU audit/repair/verify/promote 도구, CUDA preflight, 3-worker launcher, prompt 정렬 회귀 테스트. 기존 production 코드 checkout과 GitHub main은 수정·push하지 않았으며 다음 수집에는 수정된 local/reference 소스를 사용해야 한다.

Prompt/cache CPU tests 22개 및 workspace collector tests 4개 통과. 전체 reference suite는 86 passed / 1 failed이며 변경하지 않은 M³-VOS inventory failure_count 기대값 불일치가 남아 있다. 전체 tests 통과라고 판정하지 않는다. 이번 검증은 prompt alignment 및 cache 계약 검증이지 downstream segmentation 성능 보증이 아니다.

완료 후 L4 3장 모두 사용률 0%, GPU 메모리 0 MiB로 확인했다. Pod은 자동 종료하지 않았다. 승인된 Notion `모델API&실험` 위치는 현재 연결에서 찾지 못해 다른 데이터베이스에 임의로 게시하지 않았으며 본 로컬 보고서에 기록을 보존한다.
