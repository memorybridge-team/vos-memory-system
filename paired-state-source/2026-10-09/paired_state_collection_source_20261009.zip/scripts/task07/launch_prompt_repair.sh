#!/usr/bin/env bash
set -euo pipefail
repair=/workspace/CMMT-task07-repair-20261003
python=/workspace/.venvs/task07-repair-gpu/bin/python
mkdir -p "$repair/logs"
for device in 0 1 2; do
  CUDA_VISIBLE_DEVICES="$device" "$python" /workspace/repair_gpu_preflight.py
done
for device in 0 1 2; do
  CUDA_VISIBLE_DEVICES="$device" PYTHONPATH="$repair/source/src" TQDM_DISABLE=1 \
    nohup "$python" /workspace/repair_prompt_alignment.py collect \
      --shard-count 3 --shard-index "$device" \
      > "$repair/logs/gpu-$device.log" 2>&1 < /dev/null &
  echo "gpu=$device pid=$!"
done
