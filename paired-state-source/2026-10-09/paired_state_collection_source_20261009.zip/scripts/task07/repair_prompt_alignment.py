"""Audit trusted Task 07 caches on CPU; rebuild only misaligned cases on GPU.

Audit/collect/verify never overwrite production caches. The explicit promote
mode replaces verified caches only after preserving originals in --repair-root.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def number(value):
    match = re.search(r"(\d+)$", str(value))
    if match is None:
        raise ValueError(f"invalid frame token: {value}")
    return int(match.group(1))


def rgb_paths(video):
    paths = sorted((p for p in video.iterdir() if p.suffix.lower() in {".jpg", ".jpeg"}),
                   key=lambda p: number(p.stem))
    ids = [number(p.stem) for p in paths]
    if len(ids) != len(set(ids)):
        raise ValueError(f"duplicate RGB frame IDs: {video}")
    return paths, ids


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".partial")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    tmp.replace(path)


def inspect_cache(path):
    import torch
    from vos_memory_inspector.case_cache import load_case_cache
    # These are the project's own trusted pickle caches, not untrusted downloads.
    payload = load_case_cache(path)
    result = {}
    for label in ("source", "target"):
        s = payload[label + "_canonical"]
        use = s.validity.bool() & s.is_conditioning.bool()
        result[label] = sorted(set(s.frame_indices[use].tolist()))
        result[label + "_valid_frames"] = s.frame_indices[s.validity.bool()].tolist()
    result["switch_frame"] = payload["source_canonical"].switch_frame
    result["object_ids"] = list(payload["source_canonical"].object_ids)
    result["metadata"] = payload["metadata"]
    return result


def audit(base, repair):
    jobs = [
        ("lvos_train", "CMMT-task07/manifests/lvosv2_train_v1.json", "CMMT/data/LVOSv2/extracted/train", "lvos"),
        ("lvos_valid", "CMMT-task07-validation/manifests/lvosv2_valid_v1.json", "CMMT/data/LVOSv2/extracted/valid", "validation/lvos"),
        ("m3vos", "CMMT-task07-validation/manifests/m3vos_external_v1.json", "CMMT/data/M3VOS-manual/data", "validation/m3-vos"),
    ]
    targets, counts = [], {}
    for job, manifest_rel, raw_rel, cache_rel in jobs:
        manifest = base / manifest_rel
        root = base / raw_rel
        caches = base / "CMMT-task07-artifacts/production" / cache_rel / "cache"
        entries = json.loads(manifest.read_text())["cases"]
        videos, seen = {}, set()
        count = 0
        for c in entries:
            video_id = c.get("video_id", c.get("sequence"))
            object_id = int(c["object_id"])
            prompt_id = number(c.get("first_prompt_frame", c.get("first_prompt_frame_stem", c.get("prompt_frame"))))
            switch_id = number(c.get("switch_frame", c.get("switch_frame_stem")))
            if video_id not in videos:
                videos[video_id] = rgb_paths(root / "JPEGImages" / video_id)
            paths, ids = videos[video_id]
            prompt_index, switch_index = ids.index(prompt_id), ids.index(switch_id)
            if not 0 <= prompt_index <= switch_index < len(paths) - 1:
                raise ValueError(f"invalid timeline: {job}/{video_id}/{object_id}")
            key = (video_id, object_id, switch_id)
            if key in seen or prompt_index == 0:
                continue
            seen.add(key)
            matches = list(caches.glob(f"**/*_{video_id}_obj{object_id}_switch{switch_id}.pt"))
            if len(matches) != 1:
                raise ValueError(f"expected one cache for {key}: {matches}")
            old = matches[0]
            sidecar = old.with_suffix(".pt.sha256")
            actual = sha(old)
            if actual != sidecar.read_text().split()[0]:
                raise ValueError(f"checksum mismatch: {old}")
            state = inspect_cache(old)
            if state["switch_frame"] != switch_index or list(map(int, state["object_ids"])) != [object_id]:
                raise ValueError(f"cache switch/object mismatch: {old}")
            masks = [p for p in (root / "Annotations" / video_id).glob("*.png") if number(p.stem) == prompt_id]
            if len(masks) != 1:
                raise ValueError(f"missing/ambiguous prompt: {job}/{key}")
            from vos_memory_inspector.runner import load_binary_prompt
            mask = load_binary_prompt(masks[0], object_id)
            from PIL import Image
            with Image.open(paths[prompt_index]) as image:
                if mask.shape != (image.height, image.width):
                    raise ValueError(f"prompt/RGB dimensions mismatch: {key}")
            expected = [prompt_index]
            if state["source"] == expected and state["target"] == expected:
                continue
            item = dict(job=job, old_cache=str(old), old_sha256=actual,
                        video_dir=str(root / "JPEGImages" / video_id), object_id=object_id,
                        prompt_mask=str(masks[0]), prompt_mask_sha256=sha(masks[0]),
                        prompt_frame_id=prompt_id, prompt_runtime_index=prompt_index,
                        switch_frame_id=switch_id, switch_runtime_index=switch_index,
                        manifest=str(manifest), manifest_sha256=sha(manifest),
                        old_conditioning={k: state[k] for k in ("source", "target")},
                        old_metadata=state["metadata"],
                        output=str(repair / "cache" / job / old.name))
            targets.append(item)
            count += 1
        counts[job] = count
    plan = dict(schema_version="cmmt.prompt_alignment_repair.v1", targets=targets, counts=counts)
    atomic_json(repair / "repair_plan.json", plan)
    print(json.dumps(counts), f"total={len(targets)}", flush=True)
    return plan


def verify(item):
    path = Path(item["output"])
    state = inspect_cache(path)
    expected = [item["prompt_runtime_index"]]
    if state["source"] != expected or state["target"] != expected:
        raise ValueError(f"conditioning mismatch: {path}")
    if state["switch_frame"] != item["switch_runtime_index"] or list(map(int, state["object_ids"])) != [item["object_id"]]:
        raise ValueError(f"switch/object mismatch: {path}")
    if state["source_valid_frames"] != state["target_valid_frames"]:
        raise ValueError(f"source/target timeline mismatch: {path}")
    if any(not item["prompt_runtime_index"] <= f <= item["switch_runtime_index"] for f in state["source_valid_frames"]):
        raise ValueError(f"frame outside prompt/switch interval: {path}")
    m = state["metadata"]
    for k, value in {"prompt_runtime_index": item["prompt_runtime_index"], "prompt_mask_sha256": item["prompt_mask_sha256"], "prompt_object_id": item["object_id"], "cache_mode": "state_only", "active_memory_only": True}.items():
        if m.get(k) != value:
            raise ValueError(f"provenance mismatch {k}: {path}")
    for key in ("source_model_id", "target_model_id", "upstream_commit", "seed", "num_maskmem", "max_obj_ptrs_in_encoder"):
        if m.get(key) != item["old_metadata"].get(key):
            raise ValueError(f"execution contract changed {key}: {path}")
    return dict(cache=str(path), sha256=sha(path), conditioning=expected)


def collect(base, repair, plan, shard_count=1, shard_index=0, max_cases=None):
    import torch
    import warnings
    warnings.filterwarnings("error", message=".*Skipping the post-processing step.*")
    if not torch.cuda.is_available():
        raise RuntimeError("GPU collection requires a CUDA GPU; production caches unchanged")
    from vos_memory_inspector.roundtrip import prepare_cross_model_case_reference
    verified = []
    checkpoints = base / "CMMT/checkpoints"
    provenance = {"torch_version": torch.__version__, "gpu": torch.cuda.get_device_name(),
                  "source_checkpoint_sha256": sha(checkpoints / "sam2.1_hiera_small.pt"),
                  "target_checkpoint_sha256": sha(checkpoints / "sam2.1_hiera_base_plus.pt"),
                  "repair_script_sha256": sha(__file__)}
    # Deterministic longest-first balancing; one exclusive output path per shard.
    buckets = [[] for _ in range(shard_count)]
    cost = [0] * shard_count
    for item in sorted(plan["targets"], key=lambda x: (-(x["switch_runtime_index"] - x["prompt_runtime_index"] + 1), x["old_cache"])):
        owner = min(range(shard_count), key=lambda n: (cost[n], n))
        buckets[owner].append(item)
        cost[owner] += item["switch_runtime_index"] - item["prompt_runtime_index"] + 1
    items = buckets[shard_index]
    if max_cases is not None:
        items = items[:max_cases]
    for i, item in enumerate(items, 1):
        if sha(item["old_cache"]) != item["old_sha256"] or sha(item["prompt_mask"]) != item["prompt_mask_sha256"] or sha(item["manifest"]) != item["manifest_sha256"]:
            raise ValueError("inputs changed since CPU audit")
        output = Path(item["output"])
        if output.exists():
            verified.append(verify(item))
            continue
        output.parent.mkdir(parents=True, exist_ok=True)
        report = prepare_cross_model_case_reference(
            sam2_repo=repair / "sam2",
            source_config_file="configs/sam2.1/sam2.1_hiera_s.yaml",
            source_checkpoint=checkpoints / "sam2.1_hiera_small.pt", source_model_id="sam2.1-small",
            target_config_file="configs/sam2.1/sam2.1_hiera_b+.yaml",
            target_checkpoint=checkpoints / "sam2.1_hiera_base_plus.pt", target_model_id="sam2.1-base-plus",
            video_dir=item["video_dir"], prompt_mask=item["prompt_mask"], object_id=item["object_id"],
            switch_frame=item["switch_runtime_index"], prompt_frame=item["prompt_runtime_index"],
            output=output, seed=7, device="cuda", store_masks=False, active_memory_only=True,
            num_maskmem=7, max_obj_ptrs_in_encoder=16)
        atomic_json(output.with_suffix(".prepare.json"), report)
        atomic_json(output.with_suffix(".repair.json"), {**provenance, "case": item})
        verified.append(verify(item))
        atomic_json(repair / f"verified-shard-{shard_index}.json", verified)
        print(f"[{i}/{len(items)}] verified {output.name}", flush=True)
    atomic_json(repair / f"verified-shard-{shard_index}.json", verified)


def promote(repair, plan):
    """Verify the whole batch before replacement; retain every original file."""
    import shutil
    verified = [verify(item) for item in plan["targets"]]
    ledger_path = repair / "promoted.json"
    done = json.loads(ledger_path.read_text()) if ledger_path.exists() else []
    completed = {entry["old_cache"] for entry in done}
    for item, result in zip(plan["targets"], verified):
        old, new = Path(item["old_cache"]), Path(item["output"])
        if str(old) in completed:
            if sha(old) != result["sha256"]:
                raise ValueError(f"previously promoted cache changed: {old}")
            continue
        if sha(old) != item["old_sha256"]:
            raise ValueError(f"production cache changed before promotion: {old}")
        backup = repair / "original" / item["job"] / old.name
        backup.parent.mkdir(parents=True, exist_ok=True)
        pairs = [(old, new), (old.with_suffix(".pt.sha256"), new.with_suffix(".pt.sha256")),
                 (old.with_suffix(".prepare.json"), new.with_suffix(".prepare.json"))]
        for dst, src in pairs:
            saved = backup.parent / dst.name
            if saved.exists() and sha(saved) != sha(dst):
                raise ValueError(f"backup conflict: {saved}")
            if not saved.exists():
                shutil.copy2(dst, saved)
            if sha(saved) != sha(dst):
                raise ValueError(f"backup failed: {dst}")
        # No production readers/writers may run during this short three-file update.
        for dst, src in pairs:
            tmp = dst.with_suffix(dst.suffix + ".repair.partial")
            shutil.copy2(src, tmp)
            if sha(tmp) != sha(src):
                raise ValueError(f"replacement checksum failed: {dst}")
            tmp.replace(dst)
        if sha(old) != result["sha256"]:
            raise ValueError(f"promoted checksum failed: {old}")
        done.append({"old_cache": str(old), "backup": str(backup), **result})
        atomic_json(ledger_path, done)
    print(f"promoted={len(done)}; all originals retained", flush=True)


def verify_production(repair, plan):
    """Read the installed tensors again and check the retained originals."""
    ledger = json.loads((repair / "promoted.json").read_text())
    installed = {entry["old_cache"]: entry for entry in ledger}
    results = []
    for item in plan["targets"]:
        entry = installed[item["old_cache"]]
        result = verify({**item, "output": item["old_cache"]})
        if result["sha256"] != entry["sha256"]:
            raise ValueError(f"installed cache differs from promotion ledger: {item['old_cache']}")
        if sha(entry["backup"]) != item["old_sha256"]:
            raise ValueError(f"original backup differs from CPU audit: {entry['backup']}")
        results.append({**result, "backup": entry["backup"], "original_sha256": item["old_sha256"]})
    atomic_json(repair / "production_verified.json", results)
    print(f"production_verified={len(results)}; original_backups_verified={len(results)}", flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["audit", "collect", "verify", "promote", "verify-production"])
    parser.add_argument("--workspace", type=Path, default=Path("/workspace"))
    parser.add_argument("--repair-root", type=Path, default=Path("/workspace/CMMT-task07-repair-20261003"))
    parser.add_argument("--shard-count", type=int, default=1)
    parser.add_argument("--shard-index", type=int, default=0)
    parser.add_argument("--max-cases", type=int)
    args = parser.parse_args()
    if not 0 <= args.shard_index < args.shard_count:
        parser.error("invalid shard index/count")
    if args.mode == "audit":
        audit(args.workspace, args.repair_root)
    else:
        plan = json.loads((args.repair_root / "repair_plan.json").read_text())
        if args.mode == "collect":
            collect(args.workspace, args.repair_root, plan, args.shard_count, args.shard_index, args.max_cases)
        elif args.mode == "promote":
            promote(args.repair_root, plan)
        elif args.mode == "verify-production":
            verify_production(args.repair_root, plan)
        else:
            atomic_json(args.repair_root / "verified.json", [verify(item) for item in plan["targets"]])


if __name__ == "__main__":
    main()
