"""Normalize validation/external manifests to the Task 07 canonical case schema."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any


def _num(value: Any) -> int:
    m = re.search(r"(\d+)$", str(value))
    if not m:
        raise ValueError(f"frame token has no numeric suffix: {value!r}")
    return int(m.group(1))


def _sequence_cases(payload: dict[str, Any]) -> list[dict[str, Any]]:
    dataset = str(payload["dataset"])
    cases: list[dict[str, Any]] = []
    for seq in payload.get("sequences", []):
        video = str(seq["sequence"])
        frame_count = int(seq["frame_count"])
        objects = [int(x) for x in seq.get("object_ids", [])]
        for object_id in objects:
            for quantile in (0.25, 0.5, 0.75):
                switch = max(1, min(frame_count - 1, round((frame_count - 1) * quantile)))
                cases.append({
                    "case_id": f"{dataset}:{video}:obj{object_id}:switch{switch}",
                    "dataset": dataset,
                    "video_id": video,
                    "object_id": object_id,
                    "first_prompt_frame": 0,
                    "switch_frame": switch,
                    "official_split": payload.get("official_split", "external"),
                    "future_gt_available": False,
                })
    return cases


def normalize_manifest(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    dataset = str(payload.get("dataset", ""))
    if "cases" in payload:
        cases = []
        for raw in payload["cases"]:
            video = raw.get("video_id", raw.get("sequence"))
            prompt = raw.get("first_prompt_frame", raw.get("first_prompt_frame_stem", raw.get("prompt_frame", 0)))
            switch = raw.get("switch_frame", raw.get("switch_frame_stem"))
            cases.append({
                **raw,
                "case_id": raw.get("case_id", f"{dataset}:{video}:obj{raw.get('object_id', 1)}:switch{_num(switch)}"),
                "dataset": dataset,
                "video_id": str(video),
                "object_id": int(raw.get("object_id", 1)),
                "first_prompt_frame": _num(prompt),
                "switch_frame": _num(switch),
                "paired_split": raw.get("paired_split", "validation"),
            })
    elif "sequences" in payload:
        cases = _sequence_cases(payload)
    else:
        raise ValueError(f"unsupported manifest schema: {path}")
    return {
        "schema_version": "cmmt.task07.canonical_selection.v1",
        "dataset": dataset,
        "source_manifest": str(path.resolve()),
        "cases": cases,
        "future_gt_policy": "first_prompt_mask_only; future annotations are evaluation-only",
    }
