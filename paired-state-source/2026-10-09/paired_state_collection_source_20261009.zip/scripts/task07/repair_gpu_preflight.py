"""Fail closed if SAM2's CUDA hole-fill is unavailable on a repair worker."""
import json
import warnings
import torch
from sam2 import _C
from sam2.utils.misc import fill_holes_in_mask_scores

assert torch.cuda.is_available()
with warnings.catch_warnings():
    warnings.simplefilter("error")
    scores = torch.ones((1, 1, 8, 8), dtype=torch.float32, device="cuda")
    scores[:, :, 3, 3] = -1
    output = fill_holes_in_mask_scores(scores, 8)
    assert output[0, 0, 3, 3].item() > 0
    torch.cuda.synchronize()
print(json.dumps({"torch": torch.__version__, "gpu": torch.cuda.get_device_name(),
                  "extension": _C.__file__, "hole_fill": "passed"}))
