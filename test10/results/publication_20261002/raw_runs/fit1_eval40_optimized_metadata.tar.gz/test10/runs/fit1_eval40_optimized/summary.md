# test10 결과

완료 0 / 후보 160 cases. 재사용 row 0.

모든 방법 및 self-injection gate를 완료한 공통 case만 집계합니다. 부분 실행은 summary.json의 incomplete에 보존합니다.
heldout DAVIS uses train split and is exploratory

주 지표는 전환 직후 J&F입니다: 처리 프레임 switch+1..switch+10 (Base+의 첫 10개 출력) 평균. switch 프레임은 Small의 마지막 출력이라 채점하지 않습니다. +1은 Base+ 첫 출력 한 프레임, Suffix J&F는 switch+1..end 전체 평균입니다. LVOS/VOST offset은 처리 프레임(원본 5/6 프레임 간격)입니다.

전환 직후 J&F가 없는 row입니다. `--stage rescore`로 저장된 예측을 다시 채점하세요.

| Dataset | Method | Cases | Videos | 전환 직후 J&F +1..+10 (95% CI) | +1 J&F | Suffix J&F (95% CI) |
|---|---|---:|---:|---|---:|---|
| MOSEv2 | small_only | 0 | 0 | — | — | — |
| MOSEv2 | base_native | 0 | 0 | — | — | — |
| MOSEv2 | direct | 0 | 0 | — | — | — |
| MOSEv2 | affine | 0 | 0 | — | — | — |
| MOSEv2 | residual_mlp | 0 | 0 | — | — | — |
| MOSEv2 | transformer | 0 | 0 | — | — | — |
| MOSEv2 | last_mask | 0 | 0 | — | — | — |
| MOSEv2 | anchor_replay_16 | 0 | 0 | — | — | — |
| LVOSv2 | small_only | 0 | 0 | — | — | — |
| LVOSv2 | base_native | 0 | 0 | — | — | — |
| LVOSv2 | direct | 0 | 0 | — | — | — |
| LVOSv2 | affine | 0 | 0 | — | — | — |
| LVOSv2 | residual_mlp | 0 | 0 | — | — | — |
| LVOSv2 | transformer | 0 | 0 | — | — | — |
| LVOSv2 | last_mask | 0 | 0 | — | — | — |
| LVOSv2 | anchor_replay_16 | 0 | 0 | — | — | — |
| DAVIS2017 | small_only | 0 | 0 | — | — | — |
| DAVIS2017 | base_native | 0 | 0 | — | — | — |
| DAVIS2017 | direct | 0 | 0 | — | — | — |
| DAVIS2017 | affine | 0 | 0 | — | — | — |
| DAVIS2017 | residual_mlp | 0 | 0 | — | — | — |
| DAVIS2017 | transformer | 0 | 0 | — | — | — |
| DAVIS2017 | last_mask | 0 | 0 | — | — | — |
| DAVIS2017 | anchor_replay_16 | 0 | 0 | — | — | — |
| VOST | small_only | 0 | 0 | — | — | — |
| VOST | base_native | 0 | 0 | — | — | — |
| VOST | direct | 0 | 0 | — | — | — |
| VOST | affine | 0 | 0 | — | — | — |
| VOST | residual_mlp | 0 | 0 | — | — | — |
| VOST | transformer | 0 | 0 | — | — | — |
| VOST | last_mask | 0 | 0 | — | — | — |
| VOST | anchor_replay_16 | 0 | 0 | — | — | — |

## 전환 후 프레임별 J&F (point)

GT가 없는 프레임 및 suffix 밖 프레임은 —로 표시합니다. 프레임별 J/F/J&F와 채점 상태는 switch_frames.csv, CI·paired 차이·누락 수는 summary.json에 기록합니다.

| Dataset | Method | +1 | +2 | +3 | +4 | +5 | +6 | +7 | +8 | +9 | +10 |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| MOSEv2 | small_only | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | base_native | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | direct | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | affine | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | residual_mlp | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | transformer | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | last_mask | — | — | — | — | — | — | — | — | — | — |
| MOSEv2 | anchor_replay_16 | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | small_only | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | base_native | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | direct | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | affine | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | residual_mlp | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | transformer | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | last_mask | — | — | — | — | — | — | — | — | — | — |
| LVOSv2 | anchor_replay_16 | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | small_only | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | base_native | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | direct | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | affine | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | residual_mlp | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | transformer | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | last_mask | — | — | — | — | — | — | — | — | — | — |
| DAVIS2017 | anchor_replay_16 | — | — | — | — | — | — | — | — | — | — |
| VOST | small_only | — | — | — | — | — | — | — | — | — | — |
| VOST | base_native | — | — | — | — | — | — | — | — | — | — |
| VOST | direct | — | — | — | — | — | — | — | — | — | — |
| VOST | affine | — | — | — | — | — | — | — | — | — | — |
| VOST | residual_mlp | — | — | — | — | — | — | — | — | — | — |
| VOST | transformer | — | — | — | — | — | — | — | — | — | — |
| VOST | last_mask | — | — | — | — | — | — | — | — | — | — |
| VOST | anchor_replay_16 | — | — | — | — | — | — | — | — | — | — |

세부 cohort, component ablation, visible/absent/reappearance, paired CI(`paired_switch_window`, `paired`) 및 비용은 summary.json을 참조하세요.
