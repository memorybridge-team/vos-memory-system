"""Shared-frame SAM 2 sessions for handoff experiments.

A case loads its video frames once (``SharedVideoFrames``) and every run on it
(Small source, each Base+ method) gets a fresh ``inference_state`` over the same
frames. Frames are decoded lazily and only for requested positions, which keeps
long LVOS videos out of host memory. Preprocessing matches the pinned SAM 2
``load_video_frames`` (PIL resize to ``image_size``, ``/255`` in float64, cast to
float32, ImageNet mean/std).
"""

from __future__ import annotations

from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
import contextlib
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

import numpy as np
from PIL import Image
import torch


IMG_MEAN = (0.485, 0.456, 0.406)
IMG_STD = (0.229, 0.224, 0.225)


def sorted_frame_paths(video_dir: str | Path) -> list[Path]:
    """JPEG frames sorted by integer stem, as the pinned SAM 2 loader does."""

    paths = [
        path
        for path in Path(video_dir).iterdir()
        if path.suffix.lower() in {".jpg", ".jpeg"}
    ]
    if not paths:
        raise FileNotFoundError(f"no JPEG frames in {video_dir}")
    return sorted(paths, key=lambda path: int(path.stem))


def _decode(path: Path, image_size: int) -> tuple[np.ndarray, int, int]:
    with Image.open(path) as image:
        width, height = image.size
        resized = np.array(image.convert("RGB").resize((image_size, image_size)))
    return resized, height, width


class SharedVideoFrames:
    """Sequence-like frames for ``inference_state["images"]``.

    ``frames[i]`` returns the normalized ``[3, S, S]`` float32 tensor on
    ``device``. Only positions passed to ``preload`` (or accessed later) are
    decoded; decoded frames stay as uint8 on the host (3 MiB each at 1024).
    """

    def __init__(
        self,
        video_dir: str | Path,
        *,
        image_size: int = 1024,
        device: str | torch.device = "cuda",
        workers: int = 8,
    ):
        self.paths = sorted_frame_paths(video_dir)
        self.image_size = int(image_size)
        self.device = torch.device(device)
        self.workers = workers
        self._uint8: dict[int, torch.Tensor] = {}
        self._mean = torch.tensor(IMG_MEAN, dtype=torch.float32, device=self.device)[:, None, None]
        self._std = torch.tensor(IMG_STD, dtype=torch.float32, device=self.device)[:, None, None]
        with Image.open(self.paths[0]) as first:
            self.video_width, self.video_height = first.size
        self.decode_seconds = 0.0

    def __len__(self) -> int:
        return len(self.paths)

    @property
    def stems(self) -> list[str]:
        return [path.stem for path in self.paths]

    def position_of_stem(self, stem: str | int) -> int:
        target = int(stem)
        for position, path in enumerate(self.paths):
            if int(path.stem) == target:
                return position
        raise KeyError(f"frame stem {stem} is not in {self.paths[0].parent}")

    def preload(self, positions: Iterable[int]) -> None:
        import time

        missing = sorted({int(p) for p in positions} - set(self._uint8))
        if not missing:
            return
        started = time.perf_counter()
        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            for position, (array, height, width) in zip(
                missing,
                pool.map(lambda p: _decode(self.paths[p], self.image_size), missing),
            ):
                if (height, width) != (self.video_height, self.video_width):
                    raise ValueError(f"frame {self.paths[position]} changes the video size")
                self._uint8[position] = torch.from_numpy(array)  # [S, S, 3] uint8
        self.decode_seconds += time.perf_counter() - started

    def __getitem__(self, position: int) -> torch.Tensor:
        position = int(position)
        if position < 0 or position >= len(self.paths):
            raise IndexError(position)
        if position not in self._uint8:
            self.preload([position])
        image = self._uint8[position].to(self.device, non_blocking=True)
        # Same arithmetic as SAM 2: uint8 / 255.0 in float64, cast to float32, then mean/std.
        image = (image.permute(2, 0, 1).to(torch.float64) / 255.0).to(torch.float32)
        return (image - self._mean) / self._std

    def release(self) -> None:
        self._uint8.clear()


def fresh_inference_state(
    predictor: Any,
    frames: SharedVideoFrames,
    *,
    offload_state_to_cpu: bool = True,
) -> dict[str, Any]:
    """A new ``inference_state`` over shared frames (mirrors the pinned ``init_state``)."""

    compute_device = predictor.device
    storage_device = torch.device("cpu") if offload_state_to_cpu else compute_device
    return {
        "images": frames,
        "num_frames": len(frames),
        "offload_video_to_cpu": True,
        "offload_state_to_cpu": offload_state_to_cpu,
        "video_height": frames.video_height,
        "video_width": frames.video_width,
        "device": compute_device,
        "storage_device": storage_device,
        "point_inputs_per_obj": {},
        "mask_inputs_per_obj": {},
        "cached_features": {},
        "constants": {},
        "obj_id_to_idx": OrderedDict(),
        "obj_idx_to_id": OrderedDict(),
        "obj_ids": [],
        "output_dict_per_obj": {},
        "temp_output_dict_per_obj": {},
        "frames_tracked_per_obj": {},
    }


class BackboneCounter:
    """Counts image-encoder calls of a predictor (per-method accounting)."""

    def __init__(self, predictor: Any):
        self.calls: list[int] = []
        self._original = predictor.forward_image

        def counted(image: torch.Tensor):
            self.calls.append(int(image.shape[0]))
            return self._original(image)

        predictor.forward_image = counted

    def mark(self) -> int:
        return len(self.calls)


def inference_context(autocast: str | None) -> contextlib.AbstractContextManager:
    """``torch.inference_mode`` plus optional CUDA autocast (``"bfloat16"`` or ``None``)."""

    stack = contextlib.ExitStack()
    stack.enter_context(torch.inference_mode())
    if autocast is not None:
        stack.enter_context(torch.autocast("cuda", dtype=getattr(torch, autocast)))
    return stack


def propagate(
    predictor: Any,
    state: dict[str, Any],
    *,
    start: int,
    end: int,
) -> Iterator[tuple[int, torch.Tensor]]:
    """Yield ``(position, mask_logits[H, W])`` for one object from ``start`` to ``end`` inclusive."""

    for frame_idx, _object_ids, masks in predictor.propagate_in_video(
        state,
        start_frame_idx=start,
        max_frame_num_to_track=end - start,
        reverse=False,
    ):
        yield int(frame_idx), masks[0, 0]


def masks_to_bool(logits: torch.Tensor) -> np.ndarray:
    return (logits > 0).cpu().numpy()


def load_label_mask(path: str | Path, object_id: int) -> np.ndarray:
    with Image.open(path) as image:
        labels = np.array(image)
    if labels.ndim == 3:
        labels = labels[..., 0]
    return labels == int(object_id)


def positions_between(first: int, last: int) -> Sequence[int]:
    return range(int(first), int(last) + 1)
