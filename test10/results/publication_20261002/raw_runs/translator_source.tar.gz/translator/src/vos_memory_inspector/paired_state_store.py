"""Crash-safe, resumable paired-state shard store.

Layout under a configurable ``root`` (for RunPod, a path on the persistent
network volume)::

    root/store.json                               store schema and creation info
    root/<dataset>/<split>/<shard_id>.pt          tensors (torch.save, weights_only-safe)
    root/<dataset>/<split>/<shard_id>.json        manifest; written last = commit marker

Write protocol: tensors go to ``*.pt.partial``, are fsynced and renamed; the
SHA-256 of the final file is then stored in the manifest, which is written the
same way. A shard is *complete* only when its manifest exists, names the data
file and the data file's size and SHA-256 match. Interrupted writes leave only
``*.partial`` files or a data file without a manifest; both are ignored by
``index()`` and overwritten by the next ``write``. ``load`` verifies the
checksum and the manifest's tensor shapes/dtypes, so a damaged shard never
reaches training.
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Any, Iterator, Mapping

import torch


STORE_SCHEMA = "cmmt.paired_state_store.v1"
SHARD_SCHEMA = "cmmt.paired_state_shard.v1"
REQUIRED_TENSORS = {
    "source_spatial": 4,
    "target_spatial": 4,
    "source_pointer": 2,
    "target_pointer": 2,
    "frame_index": 1,
    "is_conditioning": 1,
}
REQUIRED_MANIFEST_FIELDS = (
    "dataset",
    "split",
    "video_id",
    "object_id",
    "prompt",
    "switch_frames",
    "record_selection",
    "models",
    "code_revision",
    "generation",
)
_SHARD_ID = re.compile(r"^[A-Za-z0-9._-]+$")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1 << 22):
            digest.update(chunk)
    return digest.hexdigest()


def _fsync_replace(partial: Path, final: Path) -> None:
    with partial.open("rb") as stream:
        os.fsync(stream.fileno())
    partial.replace(final)
    directory = os.open(final.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def _utc_now() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def tensor_contract(tensors: Mapping[str, torch.Tensor]) -> dict[str, dict[str, Any]]:
    return {
        name: {"shape": list(value.shape), "dtype": str(value.dtype).removeprefix("torch.")}
        for name, value in sorted(tensors.items())
    }


class ShardError(RuntimeError):
    """A shard is incomplete, damaged or inconsistent with its manifest."""


class PairedStateStore:
    def __init__(self, root: str | Path, *, create: bool = True):
        self.root = Path(root).expanduser().resolve()
        store_file = self.root / "store.json"
        if store_file.is_file():
            info = json.loads(store_file.read_text(encoding="utf-8"))
            if info.get("schema_version") != STORE_SCHEMA:
                raise ShardError(f"{store_file} has schema {info.get('schema_version')!r}")
        elif create:
            self.root.mkdir(parents=True, exist_ok=True)
            partial = store_file.with_suffix(".json.partial")
            partial.write_text(
                json.dumps({"schema_version": STORE_SCHEMA, "created_at": _utc_now()}, indent=1) + "\n",
                encoding="utf-8",
            )
            _fsync_replace(partial, store_file)
        else:
            raise FileNotFoundError(f"no paired-state store at {self.root}")

    # ---- paths -------------------------------------------------------------
    def _paths(self, dataset: str, split: str, shard_id: str) -> tuple[Path, Path]:
        for part in (dataset, split, shard_id):
            if not _SHARD_ID.match(part):
                raise ValueError(f"invalid store path component {part!r}")
        directory = self.root / dataset / split
        return directory / f"{shard_id}.pt", directory / f"{shard_id}.json"

    # ---- write -------------------------------------------------------------
    def write(
        self,
        dataset: str,
        split: str,
        shard_id: str,
        tensors: Mapping[str, torch.Tensor],
        manifest: Mapping[str, Any],
    ) -> dict[str, Any]:
        missing = sorted(set(REQUIRED_TENSORS) - set(tensors))
        if missing:
            raise ValueError(f"shard tensors are missing: {missing}")
        records = {int(value.shape[0]) for value in tensors.values()}
        if len(records) != 1:
            raise ValueError(f"all shard tensors need the same record count, got {sorted(records)}")
        for name, ndim in REQUIRED_TENSORS.items():
            if tensors[name].ndim != ndim:
                raise ValueError(f"{name} must have {ndim} dims, got {tuple(tensors[name].shape)}")
        absent = [field for field in REQUIRED_MANIFEST_FIELDS if field not in manifest]
        if absent:
            raise ValueError(f"shard manifest is missing fields: {absent}")
        data_path, manifest_path = self._paths(dataset, split, shard_id)
        data_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {name: value.detach().cpu().contiguous() for name, value in tensors.items()}
        partial = data_path.with_suffix(".pt.partial")
        torch.save(payload, partial)
        _fsync_replace(partial, data_path)
        record = {
            **dict(manifest),
            "schema_version": SHARD_SCHEMA,
            "shard_id": shard_id,
            "data_file": data_path.name,
            "bytes": data_path.stat().st_size,
            "sha256": _sha256(data_path),
            "records": records.pop(),
            "tensors": tensor_contract(payload),
            "written_at": _utc_now(),
        }
        manifest_partial = manifest_path.with_suffix(".json.partial")
        manifest_partial.write_text(json.dumps(record, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
        _fsync_replace(manifest_partial, manifest_path)
        return record

    # ---- inspect -----------------------------------------------------------
    def manifest(self, dataset: str, split: str, shard_id: str) -> dict[str, Any] | None:
        _, manifest_path = self._paths(dataset, split, shard_id)
        if not manifest_path.is_file():
            return None
        try:
            return json.loads(manifest_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return None

    def is_complete(self, dataset: str, split: str, shard_id: str, *, verify_checksum: bool = True) -> bool:
        record = self.manifest(dataset, split, shard_id)
        if record is None or record.get("schema_version") != SHARD_SCHEMA:
            return False
        data_path, _ = self._paths(dataset, split, shard_id)
        if not data_path.is_file() or data_path.stat().st_size != record.get("bytes"):
            return False
        return not verify_checksum or _sha256(data_path) == record.get("sha256")

    def index(self, dataset: str | None = None, split: str | None = None, *, verify_checksum: bool = False) -> Iterator[dict[str, Any]]:
        """Complete shards (sorted). ``verify_checksum=False`` checks size only."""

        pattern = f"{dataset or '*'}/{split or '*'}/*.json"
        for manifest_path in sorted(self.root.glob(pattern)):
            shard_dataset = manifest_path.parent.parent.name
            shard_split = manifest_path.parent.name
            shard_id = manifest_path.stem
            if self.is_complete(shard_dataset, shard_split, shard_id, verify_checksum=verify_checksum):
                yield self.manifest(shard_dataset, shard_split, shard_id)

    # ---- read --------------------------------------------------------------
    def load(self, dataset: str, split: str, shard_id: str) -> tuple[dict[str, torch.Tensor], dict[str, Any]]:
        record = self.manifest(dataset, split, shard_id)
        data_path, _ = self._paths(dataset, split, shard_id)
        if record is None:
            raise ShardError(f"shard {dataset}/{split}/{shard_id} has no manifest (incomplete write)")
        if not data_path.is_file():
            raise ShardError(f"shard data file is missing: {data_path}")
        digest = _sha256(data_path)
        if digest != record.get("sha256"):
            raise ShardError(f"checksum mismatch for {data_path}: {digest} != {record.get('sha256')}")
        tensors = torch.load(data_path, map_location="cpu", weights_only=True)
        if tensor_contract(tensors) != record.get("tensors"):
            raise ShardError(f"{data_path} tensors differ from the manifest contract")
        return tensors, record

    def fingerprint(self, dataset: str | None = None, split: str | None = None) -> dict[str, Any]:
        """Order-independent digest of the complete shards (compare after a Pod restart)."""

        shards = sorted((m["shard_id"], m["sha256"]) for m in self.index(dataset, split, verify_checksum=True))
        digest = hashlib.sha256("\n".join(f"{i} {s}" for i, s in shards).encode()).hexdigest()
        return {"shards": len(shards), "sha256": digest, "records": sum(
            m["records"] for m in self.index(dataset, split, verify_checksum=False))}


def main(argv: list[str] | None = None) -> int:
    import argparse

    parser = argparse.ArgumentParser(description="Verify a paired-state store and print its fingerprint.")
    parser.add_argument("root", type=Path)
    parser.add_argument("--dataset")
    parser.add_argument("--split")
    args = parser.parse_args(argv)
    store = PairedStateStore(args.root, create=False)
    print(json.dumps(store.fingerprint(args.dataset, args.split), indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
