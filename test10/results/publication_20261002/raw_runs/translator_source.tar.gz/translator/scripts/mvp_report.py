"""Aggregate the MVP dev evaluation into JSON + Markdown tables."""

from __future__ import annotations

import argparse
from collections import defaultdict
import json
from pathlib import Path
import random
from statistics import mean, median

import mvp_common as C

ORDER = ["small_only", "direct", "moment_match", "linear", "residual_mlp", "base"]
LABEL = {"small_only": "Small-only (ref.)", "direct": "Direct Copy", "moment_match": "Moment Match",
         "linear": "Linear", "residual_mlp": "Residual MLP", "base": "Nonlinear (base)"}


def value(row, path):
    node = row["scores"]
    for key in path:
        node = node[key] if node is not None else None
    return node


def video_mean(rows, path):
    by_video = defaultdict(list)
    for row in rows:
        v = value(row, path)
        if v is not None:
            by_video[(row["dataset"], row["video_id"])].append(v)
    means = [mean(v) for v in by_video.values()]
    return (mean(means) if means else None), len(means)


def paired_bootstrap(rows, a, b, path, *, reps=2000, seed=7):
    """Video-clustered bootstrap of mean(a - b) over videos (per-video mean of case differences)."""

    per_case = defaultdict(dict)
    for row in rows:
        if row["method"] in (a, b):
            per_case[row["case_id"]][row["method"]] = (row, value(row, path))
    by_video = defaultdict(list)
    for case, entry in per_case.items():
        if a in entry and b in entry and entry[a][1] is not None and entry[b][1] is not None:
            row = entry[a][0]
            by_video[(row["dataset"], row["video_id"])].append(entry[a][1] - entry[b][1])
    videos = [mean(v) for v in by_video.values()]
    if not videos:
        return None
    rng = random.Random(seed)
    boots = sorted(mean(rng.choices(videos, k=len(videos))) for _ in range(reps))
    return {"mean_diff": mean(videos), "ci95": [boots[int(0.025 * reps)], boots[int(0.975 * reps) - 1]], "videos": len(videos)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in (args.run_dir / "eval_dev" / "results.jsonl").read_text().splitlines()]
    train = json.loads((args.run_dir / "train" / "train_report.json").read_text())
    ckpt = json.loads((args.run_dir / "eval_ckpt" / "selection.json").read_text())
    methods = [m for m in ORDER if any(r["method"] == m for r in rows)]
    metrics = {"J&F": ("post_switch", "J_and_F"), "J": ("post_switch", "J"), "F": ("post_switch", "F"),
               "J&F@+1": ("checkpoints", "+1", "J_and_F"), "J&F@+5": ("checkpoints", "+5", "J_and_F"),
               "J&F@+20": ("checkpoints", "+20", "J_and_F"), "J&F remaining": ("remaining", "J_and_F"),
               "GT-visible J&F": ("gt_visible", "J_and_F"), "GT-absent FP rate": ("false_positives", "rate")}
    summary = {"cases": len({r["case_id"] for r in rows}), "per_dataset": {}, "runtime": {}, "vs_linear": {}, "vs_direct": {}}
    for dataset in ("all", "MOSEv2", "LVOSv2"):
        subset = [r for r in rows if dataset == "all" or r["dataset"] == dataset]
        summary["per_dataset"][dataset] = {
            m: {name: video_mean([r for r in subset if r["method"] == m], path)[0] for name, path in metrics.items()}
            | {"videos": video_mean([r for r in subset if r["method"] == m], metrics["J&F"])[1],
               "cases": sum(r["method"] == m for r in subset)} for m in methods}
        for m in methods:
            if m not in ("linear", "small_only"):
                summary["vs_linear"].setdefault(dataset, {})[m] = paired_bootstrap(subset, m, "linear", metrics["J&F"])
            if m not in ("direct", "small_only"):
                summary["vs_direct"].setdefault(dataset, {})[m] = paired_bootstrap(subset, m, "direct", metrics["J&F"])
    for m in methods:
        runtimes = [r["runtime"] for r in rows if r["method"] == m]
        if m == "small_only":
            continue
        summary["runtime"][m] = {
            "handoff_ms_median": median(1e3 * r["handoff_s"] for r in runtimes),
            "translate_ms_median": median(1e3 * r["translate_s"] for r in runtimes),
            "inject_ms_median": median(1e3 * r["inject_s"] for r in runtimes),
            "continuation_ms_per_frame_median": median(1e3 * r["continuation_s"] / max(1, r["backbone_calls_continuation"]) for r in runtimes),
            "handoff_bytes_median": median(r["handoff_bytes"] for r in runtimes),
            "past_frame_backbone_calls_max": max(r["backbone_calls_before_or_during_injection"] for r in runtimes),
            "continuation_calls_equal_future_frames": all(
                r["backbone_calls_continuation"] == row["future_positions"] for r, row in
                zip(runtimes, [x for x in rows if x["method"] == m]))}
    records = [r["records_at_switch"] for r in rows if r["method"] == "direct"]
    summary["records_at_switch"] = {"median": median(records), "max": max(records)}
    summary["train"] = {"records": train["records"], "datasets": train["datasets"], "total_s": train["total_s"],
                        "presets": {p: {"parameters": v["parameters"], "train_s": v["train_s"],
                                        "final": v["history"][-1]} for p, v in train["presets"].items()},
                        "identity_reference": train["identity_reference_first512"], "moment_match": train["moment_match"]}
    summary["checkpoint_selection"] = ckpt
    C.write_json(args.run_dir / "summary.json", summary)

    def fmt(x, pct=True):
        return "-" if x is None else (f"{100 * x:.1f}" if pct else f"{x:.3f}")

    lines = ["# MVP native-history handoff (dev)", "",
             f"- Cases: {summary['cases']} (MOSEv2 {summary['per_dataset']['MOSEv2'][methods[0]]['cases']}, "
             f"LVOS v2 {summary['per_dataset']['LVOSv2'][methods[0]]['cases']}); scores are video-averaged, J&F x100.",
             "- Post-switch J&F on annotated frames after the switch (official metric functions); offsets count sampled frames (LVOS: every 5th raw frame).", ""]
    for dataset in ("all", "MOSEv2", "LVOSv2"):
        lines += [f"## {dataset}", "", "| method | J&F | J | F | +1 | +5 | +20 | remaining | GT-visible J&F | GT-absent FP rate |",
                  "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
        for m in methods:
            s = summary["per_dataset"][dataset][m]
            lines.append(f"| {LABEL[m]} | " + " | ".join(fmt(s[k]) for k in metrics) + " |")
        lines.append("")
    lines += ["## Paired difference in post-switch J&F (video-clustered bootstrap 95% CI, x100)", "",
              "| dataset | method | vs Linear | vs Direct |", "|---|---|---:|---:|"]
    for dataset in ("all", "MOSEv2", "LVOSv2"):
        for m in methods:
            if m in ("small_only", "linear", "direct"):
                continue
            a, b = summary["vs_linear"][dataset].get(m), summary["vs_direct"][dataset].get(m)
            cell = lambda d: "-" if d is None else f"{100*d['mean_diff']:+.1f} [{100*d['ci95'][0]:+.1f}, {100*d['ci95'][1]:+.1f}]"
            lines.append(f"| {dataset} | {LABEL[m]} | {cell(a)} | {cell(b)} |")
        d = summary["vs_direct"][dataset].get("linear")
        linear_vs_direct = "-" if d is None else f"{100 * d['mean_diff']:+.1f} [{100 * d['ci95'][0]:+.1f}, {100 * d['ci95'][1]:+.1f}]"
        lines.append(f"| {dataset} | Linear | - | {linear_vs_direct} |")
    lines += ["", "## Handoff cost (median per case)", "",
              "| method | params (spatial / pointer) | translate ms | inject ms | handoff ms | handoff bytes | past-frame backbone calls (max) |",
              "|---|---|---:|---:|---:|---:|---:|"]
    for m in methods:
        if m == "small_only":
            continue
        r = summary["runtime"][m]
        p = summary["train"]["presets"].get(m, {}).get("parameters")
        params = "0" if m == "direct" else ("stats 2,560" if m == "moment_match" else f"{p['spatial']:,} / {p['pointer']:,}")
        lines.append(f"| {LABEL[m]} | {params} | {r['translate_ms_median']:.2f} | {r['inject_ms_median']:.2f} | "
                     f"{r['handoff_ms_median']:.2f} | {r['handoff_bytes_median']:,.0f} | {r['past_frame_backbone_calls_max']} |")
    (args.run_dir / "summary.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
