"""MVP handoff evaluation on dev cases.

Per case the frames are decoded once. Small tracks the object from its first
prompt with its own predictions (native history) to the switch frame (dev: on to
the end, giving the Small-only reference for free) and its canonical state is
exported. Every method then translates that state, injects it into a fresh Base+
state and continues from switch+1 without reprocessing any past frame
(backbone calls before/during injection are recorded and must be 0).

--mode ckpt: t+1 only, for checkpoint selection (all checkpoints of each preset).
--mode dev : full post-switch horizon for the selected methods.
Scoring (J / official F / diagnostics) runs in a CPU process pool.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import dataclasses
import json
import multiprocessing
from pathlib import Path
import time
import traceback

import torch

import mvp_common as C
from mvp_scoring import pack, score
from vos_memory_inspector.sam2_session import (
    BackboneCounter, SharedVideoFrames, fresh_inference_state, inference_context, load_label_mask, propagate)
from vos_memory_inspector.sam2_state import canonicalize_sam2_inference_state, inject_sam2_canonical_state
from vos_memory_inspector.transformer_translator import SAM21_MEMORY_SPEC, build_translator
from vos_memory_inspector.translators import DirectCopyTranslator, MomentMatchedCopyTranslator


def stem_name(dataset: str, stem: int) -> str:
    return f"{stem:0{8 if dataset == 'LVOSv2' else 5}d}"


def load_learned(run_dir: Path, preset: str, epoch: int):
    payload = torch.load(run_dir / "train" / preset / f"epoch_{epoch:03d}.pt", map_location="cpu", weights_only=True)
    model = build_translator(preset, SAM21_MEMORY_SPEC, SAM21_MEMORY_SPEC)
    model.load_state_dict(payload["state_dict"])
    return model.cuda().eval()


def build_methods(args, run_dir: Path) -> dict:
    train = json.loads((run_dir / "train" / "train_report.json").read_text())
    methods = {"direct": DirectCopyTranslator(SAM21_MEMORY_SPEC)}
    if args.mode == "ckpt":
        for preset, info in train["presets"].items():
            for epoch in train["checkpoint_epochs"]:
                methods[f"{preset}@{epoch}"] = load_learned(run_dir, preset, epoch)
        return methods
    chosen = json.loads((run_dir / "eval_ckpt" / "selection.json").read_text())["selected"]
    methods["moment_match"] = MomentMatchedCopyTranslator.from_payload(
        torch.load(run_dir / "train" / "moment_match.pt", map_location="cpu", weights_only=True))
    for preset, epoch in chosen.items():
        methods[preset] = load_learned(run_dir, preset, int(epoch))
    return methods


def to_device(state, device="cuda"):
    return dataclasses.replace(state, spatial_memory=state.spatial_memory.to(device),
                               object_pointer=state.object_pointer.to(device),
                               presence_logits=state.presence_logits.to(device))


def run_case(case, *, mode, small, base, methods, autocast):
    dataset = case["dataset"]
    video_dir, annotation_dir = C.case_paths(dataset, case["video_id"])
    frames = SharedVideoFrames(video_dir, device="cuda")
    first = frames.position_of_stem(case["first_prompt_stem"])
    switch = frames.position_of_stem(case["switch_stem"])
    end = frames.position_of_stem(case["end_stem"])
    horizon = switch + 1 if mode == "ckpt" else end
    frames.preload(range(first, horizon + 1))
    prompt = load_label_mask(annotation_dir / f"{stem_name(dataset, case['first_prompt_stem'])}.png", case["object_id"])
    stems = {p: frames.stems[p] for p in range(switch + 1, horizon + 1)}
    common = {"case_id": case["case_id"], "dataset": dataset, "video_id": case["video_id"],
              "object_id": case["object_id"], "switch_position": switch, "future_positions": horizon - switch,
              "decode_s": frames.decode_seconds}
    outputs = []
    # Small source with its own predictions (native history)
    state = fresh_inference_state(small, frames)
    counter = BackboneCounter(small)
    small_masks, source = {}, None
    t0 = time.perf_counter()
    with inference_context(autocast):
        small.add_new_mask(state, frame_idx=first, obj_id=1, mask=prompt)
        for position, mask in propagate(small, state, start=first, end=horizon if mode == "dev" else switch):
            if position == switch:
                source = canonicalize_sam2_inference_state(state, switch_frame=switch, strict=True)
            elif position > switch:
                small_masks[position] = pack((mask > 0).cpu().numpy())
    torch.cuda.synchronize()
    small.forward_image = counter._original
    common["small_s"] = time.perf_counter() - t0
    common["records_at_switch"] = source.valid_record_count()
    common["source_handoff_bytes"] = source.handoff_bytes()
    if mode == "dev":
        outputs.append(({"method": "small_only", "runtime": {"backbone_calls_total": len(counter.calls)}}, small_masks))
    del state
    source_gpu = to_device(source)
    for name, translator in methods.items():
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        with torch.inference_mode():  # translator in fp32 (no autocast)
            translated = translator.translate(source_gpu)
        torch.cuda.synchronize()
        translate_s = time.perf_counter() - t0
        target_state = fresh_inference_state(base, frames)
        counter = BackboneCounter(base)
        masks = {}
        with inference_context(autocast):
            t0 = time.perf_counter()
            inject_sam2_canonical_state(translated, predictor=base, inference_state=target_state)
            torch.cuda.synchronize()
            inject_s = time.perf_counter() - t0
            calls_at_injection = counter.mark()
            t0 = time.perf_counter()
            for position, mask in propagate(base, target_state, start=switch + 1, end=horizon):
                masks[position] = pack((mask > 0).cpu().numpy())
            torch.cuda.synchronize()
            continuation_s = time.perf_counter() - t0
        base.forward_image = counter._original
        outputs.append(({"method": name, "runtime": {
            "translate_s": translate_s, "inject_s": inject_s, "handoff_s": translate_s + inject_s,
            "continuation_s": continuation_s, "handoff_bytes": translated.handoff_bytes(),
            "backbone_calls_before_or_during_injection": calls_at_injection,
            "backbone_calls_continuation": len(counter.calls) - calls_at_injection}}, masks))
        del target_state, translated
    frames.release()
    tasks = [{"case_id": case["case_id"], "method": meta["method"], "masks": masks, "stems": stems,
              "annotation_dir": str(annotation_dir), "object_id": case["object_id"], "switch_position": switch,
              "context_position": switch, "stems_context": frames.stems[switch]} for meta, masks in outputs]
    return common, [meta for meta, _ in outputs], tasks


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--mode", choices=("ckpt", "dev"), required=True)
    parser.add_argument("--autocast", default="bfloat16", choices=("bfloat16", "none"))
    parser.add_argument("--workers", type=int, default=12)
    parser.add_argument("--limit", type=int)
    parser.add_argument("--ckpt-cases", type=Path, help="JSON with 'case_ids' (default: selection ckpt_case_ids)")
    args = parser.parse_args()
    autocast = None if args.autocast == "none" else args.autocast
    selection = json.loads(args.selection.read_text())
    cases = selection["dev_cases"]
    if args.mode == "ckpt":
        wanted = set(json.loads(args.ckpt_cases.read_text())["case_ids"] if args.ckpt_cases else selection["ckpt_case_ids"])
        cases = [c for c in cases if c["case_id"] in wanted]
    cases = cases[: args.limit]
    out = args.run_dir / f"eval_{args.mode}"
    out.mkdir(parents=True, exist_ok=True)
    results_path = out / "results.jsonl"
    done = set()
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            row = json.loads(line)
            done.add(row["case_id"])
    methods = build_methods(args, args.run_dir)
    meta = {"mode": args.mode, "autocast": autocast, "methods": list(methods), "cases": len(cases),
            "models": C.model_provenance(), "code_revision": C.code_revision(), "started_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
    C.write_json(out / f"run_meta_{int(time.time())}.json", meta)
    small, base = C.build_predictor("small"), C.build_predictor("base_plus")
    pool = ProcessPoolExecutor(max_workers=args.workers, mp_context=multiprocessing.get_context("spawn"))
    pending = []
    started = time.perf_counter()

    def drain(block: bool) -> None:
        still = []
        for common, metas, futures in pending:
            if block or all(f.done() for f in futures):
                rows = []
                for meta_row, future in zip(metas, futures):
                    rows.append({**common, **meta_row, **future.result()})
                with results_path.open("a", encoding="utf-8") as stream:
                    for row in rows:
                        stream.write(json.dumps(row) + "\n")
            else:
                still.append((common, metas, futures))
        pending[:] = still

    for index, case in enumerate(cases, start=1):
        if case["case_id"] in done:
            continue
        try:
            common, metas, tasks = run_case(case, mode=args.mode, small=small, base=base, methods=methods, autocast=autocast)
            pending.append((common, metas, [pool.submit(score, task) for task in tasks]))
            status = "ok"
        except Exception as exc:
            status = f"failed: {exc!r}"[:300]
            with (out / "failures.jsonl").open("a") as stream:
                stream.write(json.dumps({"case_id": case["case_id"], "error": repr(exc), "traceback": traceback.format_exc()[-2000:]}) + "\n")
        torch.cuda.empty_cache()
        drain(block=False)
        print(json.dumps({"index": index, "total": len(cases), "case_id": case["case_id"], "status": status,
                          "elapsed_s": round(time.perf_counter() - started, 1), "pending": len(pending)}), flush=True)
    drain(block=True)
    pool.shutdown()
    print("done", round(time.perf_counter() - started, 1))


if __name__ == "__main__":
    main()
