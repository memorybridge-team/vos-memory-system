"""Pick one checkpoint per learned preset from the t+1 dev episodes.

Rule (fixed before the dev evaluation): highest mean t+1 J&F over the checkpoint
cases; ties go to the later epoch.
"""

from __future__ import annotations

import argparse
import json
from collections import defaultdict
from pathlib import Path

import mvp_common as C


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path, required=True)
    args = parser.parse_args()
    rows = [json.loads(line) for line in (args.run_dir / "eval_ckpt" / "results.jsonl").read_text().splitlines()]
    table = defaultdict(lambda: defaultdict(list))
    for row in rows:
        value = row["scores"]["checkpoints"]["+1"]["J_and_F"]
        preset, _, epoch = row["method"].partition("@")
        table[preset][int(epoch) if epoch else 0].append(value)
    summary = {preset: {str(epoch): {"mean_t1_JF": sum(v) / len(v), "cases": len(v)} for epoch, v in sorted(epochs.items())}
               for preset, epochs in table.items()}
    selected = {}
    for preset, epochs in summary.items():
        if preset == "direct":
            continue
        best = max(epochs.items(), key=lambda kv: (round(kv[1]["mean_t1_JF"], 12), int(kv[0])))
        selected[preset] = int(best[0])
    report = {"rule": "max mean t+1 J&F over checkpoint cases; ties -> later epoch", "cases": len({r["case_id"] for r in rows}),
              "table": summary, "selected": selected}
    C.write_json(args.run_dir / "eval_ckpt" / "selection.json", report)
    print(json.dumps(report, indent=1))


if __name__ == "__main__":
    main()
