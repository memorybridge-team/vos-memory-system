"""Tier-1 MVP training on native-history fit shards.

Same data, seed, epochs, optimizer and learning rate for every learned preset.
Loss (plan Section 7): MSE(S_hat,S)/max(var_S,eps) + 0.1*(1-cos_pos) + MSE(p_hat,p)/max(var_p,eps),
with target variances from the fit data. Checkpoints are saved at 5 evenly spaced epochs.
Moment-Matched Copy statistics are computed from the same fit shards only.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import time

import torch
from torch.nn import functional as F

import mvp_common as C
from vos_memory_inspector.paired_state_store import PairedStateStore
from vos_memory_inspector.state_schema import CanonicalState
from vos_memory_inspector.transformer_translator import SAM21_MEMORY_SPEC, build_translator
from vos_memory_inspector.translators import MomentMatchedCopyTranslator

PRESETS = ("linear", "residual_mlp", "base")
EPS = 1e-8


def load_fit(store: PairedStateStore):
    manifests = list(store.index(split="fit", verify_checksum=False))
    n = sum(manifest["records"] for manifest in manifests)
    first, _ = store.load(manifests[0]["dataset"], "fit", manifests[0]["shard_id"])
    keys = ("source_spatial", "target_spatial", "source_pointer", "target_pointer", "is_conditioning")
    gpu = {key: torch.empty((n, *first[key].shape[1:]), dtype=first[key].dtype, device="cuda")
           for key in keys}
    del first
    offset = 0
    for manifest in manifests:
        tensors, _ = store.load(manifest["dataset"], "fit", manifest["shard_id"])
        stop = offset + manifest["records"]
        for key in keys:
            gpu[key][offset:stop].copy_(tensors[key])
        offset = stop
        del tensors
    return manifests, gpu


def fit_variances(store: PairedStateStore, manifests: list[dict]):
    stats = {key: [0, 0.0, 0.0] for key in ("target_spatial", "target_pointer")}
    for manifest in manifests:
        tensors, _ = store.load(manifest["dataset"], "fit", manifest["shard_id"])
        for key, (count, mean, m2) in stats.items():
            values = tensors[key].double()
            n = values.numel()
            chunk_mean = float(values.mean())
            chunk_m2 = float((values - chunk_mean).square().sum())
            delta = chunk_mean - mean
            total = count + n
            stats[key] = [total, mean + delta * n / total,
                          m2 + chunk_m2 + delta * delta * count * n / total]
        del tensors
    return {key: m2 / (count - 1) for key, (count, _, m2) in stats.items()}


def pseudo_pairs(store: PairedStateStore, manifests: list[dict], start_index: int = 0):
    """Yield one-shard state pairs for Moment-Matched Copy fitting."""
    for manifest in manifests[start_index:]:
        t, manifest = store.load(manifest["dataset"], "fit", manifest["shard_id"])
        k = t["frame_index"].numel()
        common = dict(presence_logits=torch.zeros(1, 1, k, 1), frame_indices=t["frame_index"].view(1, 1, k),
                      slot_order=torch.arange(k).view(1, 1, k), is_conditioning=t["is_conditioning"].view(1, 1, k),
                      validity=torch.ones(1, 1, k, dtype=torch.bool), object_ids=(manifest["shard_id"],),
                      switch_frame=int(t["frame_index"].max()))
        source = CanonicalState(spatial_memory=t["source_spatial"].view(1, 1, k, 64, 64, 64),
                                object_pointer=t["source_pointer"].view(1, 1, k, 256), **common)
        target = CanonicalState(spatial_memory=t["target_spatial"].view(1, 1, k, 64, 64, 64),
                                object_pointer=t["target_pointer"].view(1, 1, k, 256), **common)
        yield source, target


def loss_terms(model, src_s, src_p, tgt_s, tgt_p, var_s, var_p):
    s_hat, p_hat = model.translate_tensors(src_s[None, None], src_p[None, None])
    s_hat, p_hat = s_hat[0, 0], p_hat[0, 0]  # [B,C,H,W], [B,D]
    target = tgt_s.float()
    mse = F.mse_loss(s_hat, target) / max(var_s, EPS)
    cos = F.cosine_similarity(s_hat, target, dim=1, eps=EPS).mean()
    ptr = F.mse_loss(p_hat, tgt_p) / max(var_p, EPS)
    return mse + 0.1 * (1 - cos) + ptr, {"mse_norm": float(mse.detach()), "cos": float(cos.detach()),
                                         "ptr_mse_norm": float(ptr.detach())}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--store-root", type=Path, required=True)
    parser.add_argument("--run-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--checkpoints", type=int, default=5)
    parser.add_argument("--batch", type=int, default=32)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()
    store = PairedStateStore(args.store_root, create=False)
    completed_dir = args.run_dir / "train"
    completed_report = completed_dir / "train_report.json"
    if completed_report.is_file() and (completed_dir / "moment_match.pt").is_file():
        previous = json.loads(completed_report.read_text(encoding="utf-8"))
        complete = previous.get("records") == 11677 and set(previous.get("presets", {})) == set(PRESETS)
        complete = complete and previous.get("store_fingerprint") == store.fingerprint(split="fit")
        for preset in PRESETS:
            result = previous.get("presets", {}).get(preset, {})
            epochs = result.get("history", [])
            complete = complete and len(epochs) == args.epochs and epochs[-1].get("epoch") == args.epochs
            complete = complete and all((args.run_dir / name).is_file() for name in result.get("checkpoints", []))
        if complete:
            print("training artifacts already complete; skipping repeated fit", flush=True)
            return
    started = time.perf_counter()
    shards, gpu = load_fit(store)
    load_s = time.perf_counter() - started
    n = gpu["source_spatial"].shape[0]
    variances = fit_variances(store, shards)
    var_s, var_p = variances["target_spatial"], variances["target_pointer"]
    device = "cuda"
    ckpt_epochs = sorted({round(args.epochs * (i + 1) / args.checkpoints) for i in range(args.checkpoints)})
    out = args.run_dir / "train"
    out.mkdir(parents=True, exist_ok=True)
    report = {"schema_version": "cmmt.mvp_train.v1", "records": n, "shards": len(shards),
              "datasets": {d: sum(s["records"] for s in shards if s["dataset"] == d) for d in {s["dataset"] for s in shards}},
              "target_variance": {"spatial": var_s, "pointer": var_p}, "load_s": load_s,
              "optimizer": {"name": "AdamW", "lr": args.lr, "weight_decay": args.weight_decay, "batch": args.batch,
                            "epochs": args.epochs, "seed": args.seed, "schedule": "constant"},
              "loss": "mse/var_S + 0.1*(1-cos_pos) + ptr_mse/var_p", "checkpoint_epochs": ckpt_epochs,
              "store_fingerprint": store.fingerprint(split="fit"), "code_revision": C.code_revision(), "presets": {}}
    # identity reference (Direct Copy) on the fit data
    with torch.no_grad():
        idx = torch.arange(min(n, 512), device=device)
        s, p = gpu["source_spatial"][idx].float(), gpu["source_pointer"][idx]
        t_s, t_p = gpu["target_spatial"][idx].float(), gpu["target_pointer"][idx]
        report["identity_reference_first512"] = {
            "mse_norm": float(F.mse_loss(s, t_s) / var_s), "cos": float(F.cosine_similarity(s, t_s, dim=1).mean()),
            "ptr_mse_norm": float(F.mse_loss(p, t_p) / var_p)}
    for preset in PRESETS:
        torch.manual_seed(args.seed)
        model = build_translator(preset, SAM21_MEMORY_SPEC, SAM21_MEMORY_SPEC).to(device).train()
        optimizer = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        generator = torch.Generator(device="cpu").manual_seed(args.seed)
        history = []
        accumulated_s = 0.0
        state_path = out / preset / "resume.pt"
        if state_path.is_file():
            saved = torch.load(state_path, map_location="cpu", weights_only=False)
            model.load_state_dict(saved["model"])
            optimizer.load_state_dict(saved["optimizer"])
            generator.set_state(saved["generator_state"])
            history = saved["history"]
            accumulated_s = saved["train_s"]
            start_epoch = saved["epoch"]
        else:
            start_epoch = 0
        t0 = time.perf_counter()
        for epoch in range(start_epoch + 1, args.epochs + 1):
            order = torch.randperm(n, generator=generator).to(device)
            sums = {"loss": 0.0, "mse_norm": 0.0, "cos": 0.0, "ptr_mse_norm": 0.0}
            steps = 0
            for start in range(0, n, args.batch):
                batch = order[start:start + args.batch]
                optimizer.zero_grad(set_to_none=True)
                loss, terms = loss_terms(model, gpu["source_spatial"][batch], gpu["source_pointer"][batch],
                                         gpu["target_spatial"][batch], gpu["target_pointer"][batch], var_s, var_p)
                if not math.isfinite(float(loss)):
                    raise RuntimeError(f"{preset} loss became non-finite at epoch {epoch}")
                loss.backward()
                optimizer.step()
                sums["loss"] += float(loss.detach())
                for key, value in terms.items():
                    sums[key] += value
                steps += 1
            history.append({"epoch": epoch, **{k: v / steps for k, v in sums.items()}})
            if epoch in ckpt_epochs:
                path = out / preset / f"epoch_{epoch:03d}.pt"
                path.parent.mkdir(parents=True, exist_ok=True)
                torch.save({"preset": preset, "epoch": epoch,
                            "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()}}, path)
            accumulated_s += time.perf_counter() - t0
            state_path.parent.mkdir(parents=True, exist_ok=True)
            partial = state_path.with_suffix(".pt.partial")
            torch.save({"epoch": epoch, "model": model.state_dict(), "optimizer": optimizer.state_dict(),
                        "generator_state": generator.get_state(), "history": history, "train_s": accumulated_s}, partial)
            partial.replace(state_path)
            t0 = time.perf_counter()
            print(json.dumps({"preset": preset, **{k: round(v, 5) if isinstance(v, float) else v for k, v in history[-1].items()}}), flush=True)
        report["presets"][preset] = {"parameters": model.parameter_breakdown(), "train_s": accumulated_s,
                                     "history": history,
                                     "checkpoints": [str((out / preset / f"epoch_{e:03d}.pt").relative_to(args.run_dir)) for e in ckpt_epochs]}
        del model, optimizer
        torch.cuda.empty_cache()
    t0 = time.perf_counter()
    moment_resume = out / "moment_match_resume.pt"
    start_pair = 0
    if moment_resume.is_file():
        saved = torch.load(moment_resume, map_location="cpu", weights_only=False)
        start_pair = saved["next_pair"]
    moment = MomentMatchedCopyTranslator.fit(
        pseudo_pairs(store, shards, start_pair), checkpoint_path=moment_resume, start_pair=start_pair
    )
    torch.save(moment.to_payload(), out / "moment_match.pt")
    report["moment_match"] = {"fit_s": time.perf_counter() - t0, "statistics": moment.statistics_count(),
                              "statistics_bytes": moment.statistics_bytes(), "fit_summary": moment.fit_summary}
    report["total_s"] = time.perf_counter() - started
    C.write_json(out / "train_report.json", report)
    print("done", round(report["total_s"], 1), "s")


if __name__ == "__main__":
    main()
