"""CPU scoring worker for the MVP evaluation (runs in a spawn process pool)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from vos_memory_inspector.vos_metrics import evaluate_case, object_masks, read_indexed_png


def pack(mask: np.ndarray) -> tuple[tuple[int, ...], bytes]:
    return tuple(mask.shape), np.packbits(mask, axis=None).tobytes()


def unpack(shape: tuple[int, ...], data: bytes) -> np.ndarray:
    bits = np.unpackbits(np.frombuffer(data, dtype=np.uint8), count=int(np.prod(shape)))
    return bits.reshape(shape).astype(bool)


def score(task: dict[str, Any]) -> dict[str, Any]:
    """Post-switch diagnostics for one (case, method); positions index sampled frames."""

    predictions = {int(p): unpack(*packed) for p, packed in task["masks"].items()}
    annotations, voids = {}, {}
    annotation_dir = Path(task["annotation_dir"])
    for position, stem in task["stems"].items():
        path = annotation_dir / f"{stem}.png"
        if path.is_file():
            annotations[int(position)], voids[int(position)] = object_masks(read_indexed_png(path), task["object_id"])
    context = task.get("context_position")
    if context is not None and int(context) not in annotations:
        path = annotation_dir / f"{task['stems_context']}.png"
        if path.is_file():
            annotations[int(context)], voids[int(context)] = object_masks(read_indexed_png(path), task["object_id"])
    report = evaluate_case(predictions, annotations, switch_frame=task["switch_position"], voids=voids)
    keep = ("post_switch", "gt_visible", "gt_absent", "checkpoints", "remaining", "frame_counts", "false_positives")
    out = {key: report[key] for key in keep}
    out["reappearance"] = {k: report["reappearance"][k] for k in ("count", "recovered", "no_recovery_rate", "mean_recovery_length", "gt_present_at_switch")}
    out["j_parity_with_official"] = report["j_parity_with_official"]
    out["F_unavailable_reason"] = report["metric_sources"]["F_unavailable_reason"]
    return {"case_id": task["case_id"], "method": task["method"], "scores": out}
