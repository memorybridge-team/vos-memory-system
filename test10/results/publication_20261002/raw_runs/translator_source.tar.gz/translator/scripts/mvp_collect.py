"""Collect native-history Small/Base+ record pairs for the MVP fit objects.

Per object: frames are decoded once and shared; Small and Base+ each track the
object from its first prompt (ground-truth mask) with their own predictions up
to the object's last switch frame. At every switch the canonical state is
exported and the records SAM 2 memory attention reads next (conditioning records
+ the 7 most recent non-conditioning records) are kept. Records are deduplicated
by frame across switches and paired by frame. One shard per object.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time
import traceback

import torch

import mvp_common as C
from vos_memory_inspector.paired_state_store import PairedStateStore
from vos_memory_inspector.sam2_session import (
    SharedVideoFrames, fresh_inference_state, inference_context, load_label_mask, propagate)
from vos_memory_inspector.sam2_state import canonicalize_sam2_inference_state

RECENT_NON_COND = 7
SELECTION_RULE = f"per switch: all conditioning records + {RECENT_NON_COND} most recent non-conditioning records at or before the switch; deduplicated by frame"


def stem_name(dataset: str, stem: int) -> str:
    return f"{stem:0{8 if dataset == 'LVOSv2' else 5}d}"


def select_records(canonical) -> list[int]:
    frames = canonical.frame_indices[0, 0]
    cond = canonical.is_conditioning[0, 0]
    valid = canonical.validity[0, 0]
    order = [i for i in range(frames.numel()) if valid[i]]
    keep = [i for i in order if cond[i]]
    non_cond = sorted((i for i in order if not cond[i]), key=lambda i: int(frames[i]))
    return keep + non_cond[-RECENT_NON_COND:]


def run_model(predictor, frames, *, prompt, first, switches, autocast):
    state = fresh_inference_state(predictor, frames)
    per_switch, records = {}, {}
    wanted = set(switches)
    with inference_context(autocast):
        predictor.add_new_mask(state, frame_idx=first, obj_id=1, mask=prompt)
        for position, _mask in propagate(predictor, state, start=first, end=max(switches)):
            if position not in wanted:
                continue
            canonical = canonicalize_sam2_inference_state(state, switch_frame=position, strict=True)
            chosen = select_records(canonical)
            per_switch[position] = {
                "discrete": tuple(getattr(canonical, name)[0, 0].clone() for name in
                                  ("frame_indices", "slot_order", "is_conditioning", "validity")),
                "frames": [int(canonical.frame_indices[0, 0, i]) for i in chosen],
                "dtypes": {"spatial": str(canonical.spatial_memory.dtype), "pointer": str(canonical.object_pointer.dtype)},
            }
            for i in chosen:
                frame = int(canonical.frame_indices[0, 0, i])
                spatial = canonical.spatial_memory[0, 0, i].to(torch.bfloat16).clone()
                pointer = canonical.object_pointer[0, 0, i].float().clone()
                conditioning = bool(canonical.is_conditioning[0, 0, i])
                if frame in records:  # the same frame seen from a later switch must be unchanged
                    old = records[frame]
                    if not (torch.equal(old[0], spatial) and torch.equal(old[1], pointer)):
                        raise RuntimeError(f"record for frame {frame} changed between switches")
                else:
                    records[frame] = (spatial, pointer, conditioning)
            del canonical
    return per_switch, records


def collect_object(obj, *, small, base, store, run_meta, autocast):
    dataset = obj["dataset"]
    video_dir, annotation_dir = C.case_paths(dataset, obj["video_id"])
    frames = SharedVideoFrames(video_dir, device="cuda")
    first = frames.position_of_stem(obj["first_prompt_stem"])
    switches = sorted(frames.position_of_stem(s) for s in obj["switch_stems"])
    frames.preload(range(first, max(switches) + 1))
    prompt = load_label_mask(annotation_dir / f"{stem_name(dataset, obj['first_prompt_stem'])}.png", obj["object_id"])
    timings = {"decode_s": frames.decode_seconds}
    started = time.perf_counter()
    src_switch, src = run_model(small, frames, prompt=prompt, first=first, switches=switches, autocast=autocast)
    timings["small_s"] = time.perf_counter() - started
    started = time.perf_counter()
    tgt_switch, tgt = run_model(base, frames, prompt=prompt, first=first, switches=switches, autocast=autocast)
    timings["base_plus_s"] = time.perf_counter() - started
    for s in switches:  # one discrete timeline for both models
        for a, b, name in zip(src_switch[s]["discrete"], tgt_switch[s]["discrete"],
                              ("frame_indices", "slot_order", "is_conditioning", "validity")):
            if not torch.equal(a, b):
                raise RuntimeError(f"paired {name} differ at switch {s}")
    if set(src) != set(tgt):
        raise RuntimeError("paired record frames differ")
    order = sorted(src)
    stems = frames.stems
    membership = torch.tensor([[f in src_switch[s]["frames"] for s in switches] for f in order], dtype=torch.bool)
    tensors = {
        "source_spatial": torch.stack([src[f][0] for f in order]),
        "target_spatial": torch.stack([tgt[f][0] for f in order]),
        "source_pointer": torch.stack([src[f][1] for f in order]),
        "target_pointer": torch.stack([tgt[f][1] for f in order]),
        "frame_index": torch.tensor(order, dtype=torch.int64),
        "frame_stem": torch.tensor([int(stems[f]) for f in order], dtype=torch.int64),
        "is_conditioning": torch.tensor([src[f][2] for f in order], dtype=torch.bool),
        "switch_membership": membership,
    }
    manifest = {
        "dataset": dataset, "split": "fit", "video_id": obj["video_id"], "object_id": obj["object_id"],
        "case_ids": obj["case_ids"],
        "prompt": {"type": "ground_truth_mask", "frame_stem": obj["first_prompt_stem"], "frame_position": first},
        "switch_frames": [{"stem": int(stems[s]), "position": s, "records_total": int(src_switch[s]["discrete"][3].sum())} for s in switches],
        "record_selection": SELECTION_RULE,
        "runtime_dtypes": {"source": src_switch[switches[0]]["dtypes"], "target": tgt_switch[switches[0]]["dtypes"]},
        "stored_dtypes": {"spatial": "bfloat16", "pointer": "float32"},
        "models": run_meta["models"], "code_revision": run_meta["code_revision"],
        "generation": {"mode": "native_history", "autocast": autocast, "offload_state_to_cpu": True,
                       "frames": "SharedVideoFrames (pinned SAM 2 preprocessing)", "selection": run_meta["selection"]},
        "timings": timings,
    }
    record = store.write(dataset, "fit", f"{obj['video_id']}__obj{obj['object_id']}", tensors, manifest)
    frames.release()
    return record, timings


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--store-root", type=Path, required=True, help="persistent volume path")
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--autocast", default="bfloat16", choices=("bfloat16", "none"))
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    autocast = None if args.autocast == "none" else args.autocast
    selection = json.loads(args.selection.read_text())
    store = PairedStateStore(args.store_root)
    run_meta = {"models": C.model_provenance(), "code_revision": C.code_revision(),
                "selection": {"file": args.selection.name, "sha256": C.sha256_file(args.selection)}}
    small, base = C.build_predictor("small"), C.build_predictor("base_plus")
    objects = selection["fit_objects"][: args.limit]
    args.log.parent.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    for index, obj in enumerate(objects, start=1):
        shard_id = f"{obj['video_id']}__obj{obj['object_id']}"
        entry = {"index": index, "total": len(objects), "dataset": obj["dataset"], "shard_id": shard_id}
        if store.is_complete(obj["dataset"], "fit", shard_id, verify_checksum=True):
            entry["state"] = "reused"
        else:
            try:
                record, timings = collect_object(obj, small=small, base=base, store=store, run_meta=run_meta, autocast=autocast)
                entry.update(state="written", records=record["records"], bytes=record["bytes"], **timings)
            except Exception as exc:  # keep going; failures are logged and retried on the next run
                entry.update(state="failed", error=repr(exc)[:500], traceback=traceback.format_exc()[-1500:])
            torch.cuda.empty_cache()
        entry["elapsed_s"] = time.perf_counter() - started
        with args.log.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps(entry) + "\n")
        print(json.dumps({k: entry[k] for k in ("index", "state", "shard_id", "elapsed_s")}), flush=True)


if __name__ == "__main__":
    main()
