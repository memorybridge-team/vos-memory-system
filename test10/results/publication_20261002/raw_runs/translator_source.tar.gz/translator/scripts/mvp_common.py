"""Shared constants and helpers for the MVP handoff scripts (not part of the library)."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
from typing import Any

REPO = Path(__file__).resolve().parents[1]
SAM2_REPO = Path("/home/home/test/sam2")
DATA = Path("/home/home/test/vos-data")
CKPT = Path("/home/home/test/vos-checkpoints")
MODELS = {
    "small": {"config": "configs/sam2.1/sam2.1_hiera_s.yaml", "checkpoint": CKPT / "sam2.1_hiera_small.pt",
              "model_id": "sam2.1_hiera_small"},
    "base_plus": {"config": "configs/sam2.1/sam2.1_hiera_b+.yaml", "checkpoint": CKPT / "sam2.1_hiera_base_plus.pt",
                  "model_id": "sam2.1_hiera_base_plus"},
}
DATASETS = {
    "MOSEv2": {"root": DATA / "MOSEv2/train", "stride": 1},
    "LVOSv2": {"root": DATA / "LVOS_V2/train", "stride": 5},
}
# Frozen Task 03 manifests were removed on refactor/project-cleanup; read them from history.
MANIFEST_COMMIT = "80f0c9b"
MANIFESTS = {
    "MOSEv2": ("mosev2_train_v1", "mosev2_train_v1_fit", "mosev2_train_v1_development"),
    "LVOSv2": ("lvosv2_train_v1", "lvosv2_train_v1_fit", "lvosv2_train_v1_development"),
}

if str(SAM2_REPO) not in sys.path:
    sys.path.insert(0, str(SAM2_REPO))


def git(*args: str, cwd: Path = REPO) -> str:
    return subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True).stdout


def historical_manifest(name: str) -> dict[str, Any]:
    """Manifest content as last committed before its deletion."""

    deleted = git("log", "--all", "--format=%H", "--diff-filter=D", "-1", "--", f"manifests/{name}.json").strip()
    ref = f"{deleted}^" if deleted else MANIFEST_COMMIT
    return json.loads(git("show", f"{ref}:manifests/{name}.json"))


def code_revision() -> dict[str, Any]:
    """Commit plus a digest of the library and MVP scripts actually on disk
    (covers uncommitted and untracked files)."""

    status = git("status", "--porcelain").strip()
    files = sorted([*REPO.glob("src/vos_memory_inspector/**/*.py"), *REPO.glob("scripts/mvp_*.py")])
    digest = hashlib.sha256()
    for path in files:
        digest.update(f"{path.relative_to(REPO)} {sha256_file(path)}\n".encode())
    return {"commit": git("rev-parse", "HEAD").strip(), "branch": git("rev-parse", "--abbrev-ref", "HEAD").strip(),
            "dirty": bool(status), "uncommitted": [line[3:] for line in status.splitlines()],
            "source_digest": digest.hexdigest(), "source_files": len(files)}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1 << 22):
            digest.update(chunk)
    return digest.hexdigest()


_CKPT_SHA: dict[str, str] = {}


def model_provenance() -> dict[str, Any]:
    out = {}
    for name, model in MODELS.items():
        key = str(model["checkpoint"])
        if key not in _CKPT_SHA:
            _CKPT_SHA[key] = sha256_file(model["checkpoint"])
        out[name] = {"model_id": model["model_id"], "config": model["config"],
                     "checkpoint": model["checkpoint"].name, "checkpoint_sha256": _CKPT_SHA[key]}
    out["sam2_commit"] = git("rev-parse", "HEAD", cwd=SAM2_REPO).strip()
    return out


def build_predictor(name: str, device: str = "cuda"):
    from sam2.build_sam import build_sam2_video_predictor

    model = MODELS[name]
    return build_sam2_video_predictor(config_file=model["config"], ckpt_path=str(model["checkpoint"]), device=device)


def case_paths(dataset: str, video: str) -> tuple[Path, Path]:
    root = DATASETS[dataset]["root"]
    return root / "JPEGImages" / video, root / "Annotations" / video


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    partial = path.with_suffix(path.suffix + ".partial")
    partial.write_text(json.dumps(payload, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    partial.replace(path)
