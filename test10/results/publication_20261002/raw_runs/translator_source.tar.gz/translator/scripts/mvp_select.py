"""Deterministic MVP selection from the frozen Task 03 train manifests (seed 7).

- fit objects: MOSEv2 500, LVOS v2 100, hash-ranked over (video, object) of the fit split;
  each keeps all of its manifest switch frames.
- dev cases: MOSEv2 300 (at most 1 per video), LVOS v2 100 (at most 2 per video),
  hash-ranked within the development split.
- checkpoint subset: the first 24 MOSEv2 + 8 LVOS v2 dev cases in rank order.
Objects whose prompt annotation or frames are missing locally are skipped and listed.
"""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import mvp_common as C


def rank(seed: int, *parts: object) -> str:
    return hashlib.sha256(":".join(str(p) for p in (seed, *parts)).encode()).hexdigest()


def norm_case(dataset: str, case: dict) -> dict:
    video = case["video_id"]
    first = case.get("first_prompt_frame")
    if first is None:
        first = int(case.get("first_prompt_frame_stem", "0"))
    return {
        "case_id": case["case_id"], "dataset": dataset, "video_id": video, "object_id": int(case["object_id"]),
        "first_prompt_stem": int(first), "switch_stem": int(case["switch_frame"]),
        "end_stem": int(case["future_end_frame"]), "tags": case.get("tags", []),
    }


def available(dataset: str, case: dict) -> bool:
    video_dir, annotation_dir = C.case_paths(dataset, case["video_id"])
    width = 8 if dataset == "LVOSv2" else 5
    prompt = annotation_dir / f"{case['first_prompt_stem']:0{width}d}.png"
    return video_dir.is_dir() and prompt.is_file()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()
    budget = {"MOSEv2": {"fit_objects": 500, "dev_cases": 300, "dev_per_video": 1, "ckpt": 24},
              "LVOSv2": {"fit_objects": 100, "dev_cases": 100, "dev_per_video": 2, "ckpt": 8}}
    selection = {"schema_version": "cmmt.mvp_selection.v1", "seed": args.seed,
                 "source": {"manifest_commit": C.MANIFEST_COMMIT, "manifests": {}},
                 "fit_objects": [], "dev_cases": [], "ckpt_case_ids": [], "skipped": []}
    for dataset, (source, fit, dev) in C.MANIFESTS.items():
        manifest = C.historical_manifest(source)
        fit_videos = set(C.historical_manifest(fit)["videos"])
        dev_videos = set(C.historical_manifest(dev)["videos"])
        assert not fit_videos & dev_videos, "fit/dev video overlap"
        selection["source"]["manifests"][dataset] = {"cases": source, "content_sha256": manifest.get("content_sha256")}
        cases = [norm_case(dataset, c) for c in manifest["cases"]]
        # fit objects
        objects: dict[tuple, list] = {}
        for case in cases:
            if case["video_id"] in fit_videos:
                objects.setdefault((case["video_id"], case["object_id"]), []).append(case)
        chosen = 0
        for key in sorted(objects, key=lambda k: rank(args.seed, dataset, *k)):
            group = sorted(objects[key], key=lambda c: c["switch_stem"])
            if chosen >= budget[dataset]["fit_objects"]:
                break
            if not available(dataset, group[0]) or len({c["first_prompt_stem"] for c in group}) != 1:
                selection["skipped"].append({"dataset": dataset, "video_id": key[0], "object_id": key[1],
                                             "reason": "missing local data or inconsistent prompt frame"})
                continue
            selection["fit_objects"].append({
                "dataset": dataset, "video_id": key[0], "object_id": key[1],
                "first_prompt_stem": group[0]["first_prompt_stem"],
                "switch_stems": sorted({c["switch_stem"] for c in group}),
                "case_ids": [c["case_id"] for c in group]})
            chosen += 1
        # dev cases
        per_video: dict[str, int] = {}
        picked = []
        for case in sorted((c for c in cases if c["video_id"] in dev_videos), key=lambda c: rank(args.seed, dataset, c["case_id"])):
            if len(picked) >= budget[dataset]["dev_cases"]:
                break
            if per_video.get(case["video_id"], 0) >= budget[dataset]["dev_per_video"] or not available(dataset, case):
                continue
            per_video[case["video_id"]] = per_video.get(case["video_id"], 0) + 1
            picked.append(case)
        selection["dev_cases"].extend(picked)
        selection["ckpt_case_ids"].extend(c["case_id"] for c in picked[: budget[dataset]["ckpt"]])
    selection["counts"] = {
        "fit_objects": {d: sum(o["dataset"] == d for o in selection["fit_objects"]) for d in C.MANIFESTS},
        "fit_switches": {d: sum(len(o["switch_stems"]) for o in selection["fit_objects"] if o["dataset"] == d) for d in C.MANIFESTS},
        "dev_cases": {d: sum(c["dataset"] == d for c in selection["dev_cases"]) for d in C.MANIFESTS},
        "dev_videos": {d: len({c["video_id"] for c in selection["dev_cases"] if c["dataset"] == d}) for d in C.MANIFESTS},
        "ckpt_cases": len(selection["ckpt_case_ids"]), "skipped": len(selection["skipped"])}
    C.write_json(args.output, selection)
    print(selection["counts"])


if __name__ == "__main__":
    main()
