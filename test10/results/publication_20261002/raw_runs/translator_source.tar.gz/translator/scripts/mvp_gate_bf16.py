"""Gate before using bf16 autocast + shared frames for the MVP.

1. SharedVideoFrames equals the pinned SAM 2 loader bit for bit.
2. Base+ self-injection under bf16: native run -> export at switch -> inject into a
   fresh state -> continue; future logits must be identical to the native run and
   no past frame may reach the backbone.
3. Informational: bf16 vs fp32 native agreement and per-frame time.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np
import torch

import mvp_common as C
from vos_memory_inspector.sam2_session import (
    BackboneCounter, SharedVideoFrames, fresh_inference_state, inference_context, load_label_mask, propagate)
from vos_memory_inspector.sam2_state import canonicalize_sam2_inference_state, inject_sam2_canonical_state


def stem_name(dataset: str, stem: int) -> str:
    return f"{stem:0{8 if dataset == 'LVOSv2' else 5}d}"


def native_run(predictor, frames, *, prompt, first, switch, end, autocast):
    state = fresh_inference_state(predictor, frames)
    counter = BackboneCounter(predictor)
    logits, canonical = {}, None
    started = time.perf_counter()
    with inference_context(autocast):
        predictor.add_new_mask(state, frame_idx=first, obj_id=1, mask=prompt)
        for position, mask in propagate(predictor, state, start=first, end=end):
            logits[position] = mask.float().cpu()
            if position == switch:
                canonical = canonicalize_sam2_inference_state(state, switch_frame=switch, strict=True)
    torch.cuda.synchronize()
    predictor.forward_image = counter._original
    return logits, canonical, time.perf_counter() - started, len(counter.calls)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--selection", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    selection = json.loads(args.selection.read_text())
    report = {"cases": []}
    # 1. frame parity on a real 1080p video
    from sam2.utils.misc import load_video_frames
    case = next(c for c in selection["dev_cases"] if c["dataset"] == "MOSEv2")
    video_dir, _ = C.case_paths("MOSEv2", case["video_id"])
    reference, height, width = load_video_frames(str(video_dir), image_size=1024, offload_video_to_cpu=True)
    frames = SharedVideoFrames(video_dir, device="cpu")
    positions = [0, len(frames) // 2, len(frames) - 1]
    report["frame_parity"] = {"video": case["video_id"], "positions": positions,
                              "identical": all(torch.equal(frames[p], reference[p]) for p in positions),
                              "size_matches": (frames.video_height, frames.video_width) == (height, width)}
    del reference
    base = C.build_predictor("base_plus")
    for dataset in ("MOSEv2", "LVOSv2"):
        case = next(c for c in selection["dev_cases"] if c["dataset"] == dataset)
        video_dir, annotation_dir = C.case_paths(dataset, case["video_id"])
        frames = SharedVideoFrames(video_dir, device="cuda")
        first = frames.position_of_stem(case["first_prompt_stem"])
        switch = frames.position_of_stem(case["switch_stem"])
        end = frames.position_of_stem(case["end_stem"])
        frames.preload(range(first, end + 1))
        prompt = load_label_mask(annotation_dir / f"{stem_name(dataset, case['first_prompt_stem'])}.png", case["object_id"])
        native, canonical, native_s, native_calls = native_run(base, frames, prompt=prompt, first=first, switch=switch, end=end, autocast="bfloat16")
        # inject and continue
        state = fresh_inference_state(base, frames)
        counter = BackboneCounter(base)
        with inference_context("bfloat16"):
            inject_sam2_canonical_state(canonical, predictor=base, inference_state=state)
            calls_after_injection = counter.mark()
            injected = {p: m.float().cpu() for p, m in propagate(base, state, start=switch + 1, end=end)}
        base.forward_image = counter._original
        future = sorted(p for p in native if p > switch)
        max_diff = max(float((native[p] - injected[p]).abs().max()) for p in future)
        iou = [float(((native[p] > 0) & (injected[p] > 0)).sum() / max(((native[p] > 0) | (injected[p] > 0)).sum(), 1)) for p in future]
        fp32, _, fp32_s, _ = native_run(base, frames, prompt=prompt, first=first, switch=switch, end=end, autocast=None)
        agree = [float(((native[p] > 0) & (fp32[p] > 0)).sum() / max(((native[p] > 0) | (fp32[p] > 0)).sum(), 1)) if ((native[p] > 0) | (fp32[p] > 0)).any() else 1.0 for p in native]
        report["cases"].append({
            "dataset": dataset, "case_id": case["case_id"], "frames_processed": len(native),
            "future_frames": len(future), "records_at_switch": canonical.valid_record_count(),
            "self_injection": {"max_abs_logit_diff": max_diff, "min_binary_iou": min(iou),
                               "backbone_calls_during_injection": calls_after_injection,
                               "backbone_calls_during_continuation": len(counter.calls) - calls_after_injection},
            "bf16_vs_fp32_native_mean_iou": float(np.mean(agree)), "bf16_vs_fp32_native_min_iou": float(np.min(agree)),
            "ms_per_frame": {"bf16": native_s / len(native) * 1e3, "fp32": fp32_s / len(native) * 1e3},
            "frame_decode_ms_per_frame": frames.decode_seconds / len(native) * 1e3})
        print(json.dumps(report["cases"][-1]), flush=True)
    report["passed"] = bool(report["frame_parity"]["identical"] and all(
        c["self_injection"]["max_abs_logit_diff"] == 0.0 and c["self_injection"]["backbone_calls_during_injection"] == 0
        and c["self_injection"]["backbone_calls_during_continuation"] == c["future_frames"] for c in report["cases"]))
    C.write_json(args.output, report)
    print("frame_parity", report["frame_parity"], "PASSED" if report["passed"] else "FAILED")


if __name__ == "__main__":
    main()
